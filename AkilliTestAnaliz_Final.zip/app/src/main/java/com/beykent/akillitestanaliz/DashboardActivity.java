package com.beykent.akillitestanaliz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private TextView txtTotalCorrect, txtTotalWrong, txtTotalEmpty;
    private TextView txtSummaryMain, txtSummarySub;
    private TextView txtKocMesaji, txtTodayPlan, txtRecentActivity, txtDashboardMotivation;
    private TextView btnExamTYT, btnExamAYT, btnExamLGS, btnExamKPSS;
    private ProgressBar progressOverall;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        dbHelper = new DatabaseHelper(this);

        // ID'leri XML ile eşleştiriyoruz
        txtTotalCorrect = findViewById(R.id.txtTotalCorrect);
        txtTotalWrong = findViewById(R.id.txtTotalWrong);
        txtTotalEmpty = findViewById(R.id.txtTotalEmpty);
        txtSummaryMain = findViewById(R.id.txtSummaryMain);
        txtSummarySub = findViewById(R.id.txtSummarySub);
        txtKocMesaji = findViewById(R.id.txtKocMesaji);
        txtTodayPlan = findViewById(R.id.txtTodayPlan);
        txtRecentActivity = findViewById(R.id.txtRecentActivity);
        txtDashboardMotivation = findViewById(R.id.txtDashboardMotivation);
        btnExamTYT = findViewById(R.id.btnExamTYT);
        btnExamAYT = findViewById(R.id.btnExamAYT);
        btnExamLGS = findViewById(R.id.btnExamLGS);
        btnExamKPSS = findViewById(R.id.btnExamKPSS);
        progressOverall = findViewById(R.id.progressOverall);

        setupExamFilterButtons();

        // Buton Yönlendirmeleri
        findViewById(R.id.cardBooks).setOnClickListener(v ->
                startActivity(new Intent(this, BooksActivity.class)));

        findViewById(R.id.cardTests).setOnClickListener(v ->
                startActivity(new Intent(this, TestsActivity.class)));

        findViewById(R.id.cardExamEntry).setOnClickListener(v ->
                startActivity(new Intent(this, ExamEntryActivity.class)));

        findViewById(R.id.cardWrongBox).setOnClickListener(v ->
                startActivity(new Intent(this, WrongBoxActivity.class)));

        findViewById(R.id.cardReports).setOnClickListener(v ->
                startActivity(new Intent(this, ReportsActivity.class)));

        findViewById(R.id.cardAdvanced).setOnClickListener(v ->
                startActivity(new Intent(this, AdvancedFeaturesActivity.class)));

        findViewById(R.id.cardExamTimes).setOnClickListener(v -> {
            Intent intent = new Intent(this, ExamTimeSettingActivity.class);
            intent.putExtra("exam", dbHelper.getActiveExamType());
            startActivity(intent);
        });
    }


    private void setupExamFilterButtons() {
        btnExamTYT.setOnClickListener(v -> changeExamType(TimePrefs.EXAM_TYT));
        btnExamAYT.setOnClickListener(v -> changeExamType(TimePrefs.EXAM_AYT));
        btnExamLGS.setOnClickListener(v -> changeExamType(TimePrefs.EXAM_LGS));
        btnExamKPSS.setOnClickListener(v -> changeExamType(TimePrefs.EXAM_KPSS));
    }

    private void changeExamType(String type) {
        dbHelper.setActiveExamType(type);
        updateDashboardData();
    }

    private void updateExamFilterUi(String active) {
        setExamButtonState(btnExamTYT, TimePrefs.EXAM_TYT.equals(active));
        setExamButtonState(btnExamAYT, TimePrefs.EXAM_AYT.equals(active));
        setExamButtonState(btnExamLGS, TimePrefs.EXAM_LGS.equals(active));
        setExamButtonState(btnExamKPSS, TimePrefs.EXAM_KPSS.equals(active));
    }

    private void setExamButtonState(TextView button, boolean selected) {
        if (button == null) return;
        button.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip_unselected);
        button.setTextColor(android.graphics.Color.parseColor(selected ? "#0F172A" : "#2563EB"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDashboardData();
    }

    private void updateDashboardData() {
        // Veritabanı verilerini al
        String aktifSinav = dbHelper.getActiveExamType();
        updateExamFilterUi(aktifSinav);

        int correct = dbHelper.getCountByStatus(DatabaseHelper.COL_CORRECT);
        int wrong = dbHelper.getCountByStatus(DatabaseHelper.COL_WRONG);
        int empty = dbHelper.getCountByStatus(DatabaseHelper.COL_EMPTY);
        int total = correct + wrong + empty;

        // Sayısal verileri güncelle
        txtTotalCorrect.setText(correct + "\nDoğru");
        txtTotalWrong.setText(wrong + "\nYanlış");
        txtTotalEmpty.setText(empty + "\nBoş");

        // Genel ilerleme çubuğu
        int basari = dbHelper.getOverallSuccessPercent();
        progressOverall.setProgress(basari);

        // Metin alanlarını dinamik hale getir
        if (total > 0) {
            txtSummaryMain.setText(aktifSinav + " başarı: %" + basari);
            txtSummarySub.setText("Bu panel sadece " + aktifSinav + " verisini gösterir. Toplam " + total + " soru, " + dbHelper.getSolvedTestCount() + " test ve " + dbHelper.getExamCount() + " deneme kaydı var.");
            txtTodayPlan.setText(dbHelper.getDashboardDailyPlan());
        } else {
            txtSummaryMain.setText("Hazırlık aşamasındasın");
            txtSummarySub.setText("İlk testini veya denemeni ekleyince koçluk paneli dolmaya başlar.");
            txtTodayPlan.setText("Bugünkü hedef: 1 test sonucu veya 1 deneme ekle.");
        }

        // ── Tavsiye Motoru: koçluk mesajını göster ─────────────────────────────
        txtKocMesaji.setText(dbHelper.getGenelKocMesaji());
        txtRecentActivity.setText(dbHelper.getDashboardRecentSummary());
        if (txtDashboardMotivation != null) txtDashboardMotivation.setText(dbHelper.getDailyMotivation());
    }
}
