package com.beykent.akillitestanaliz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String msg = intent == null ? null : intent.getStringExtra("message");
        if (msg == null || msg.trim().isEmpty()) msg = "Bugünkü çalışma hedefini tamamla.";
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        String channelId = "study_reminder";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(channelId, "Çalışma Hatırlatmaları", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(context, channelId) : new Notification.Builder(context);
        b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Akıllı Test Analiz")
                .setContentText(msg)
                .setAutoCancel(true);
        nm.notify(42, b.build());
    }
}
