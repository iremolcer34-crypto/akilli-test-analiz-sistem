package com.beykent.akillitestanaliz.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "publishers")
public class Publisher {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;

    public Publisher(String name) {
        this.name = name;
    }
}

