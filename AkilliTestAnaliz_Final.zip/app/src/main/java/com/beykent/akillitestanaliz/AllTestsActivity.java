package com.beykent.akillitestanaliz;

import android.app.AlertDialog;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class AllTestsActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private LinearLayout list;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundResource(R.drawable.bg_app);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(root);
        TextView title = title("Tüm Test Geçmişi", 24);
        TextView sub = body("Bu sayfa eski testleri aşağı yığmak yerine ayrı yerde tutar. Kayıtlara dokunarak silebilirsin.");
        root.addView(title); root.addView(sub);
        list = root;
        setContentView(scroll);
        if (getSupportActionBar()!=null) { getSupportActionBar().setTitle("Tüm Test Geçmişi"); getSupportActionBar().setDisplayHomeAsUpEnabled(true); }
        db = new DatabaseHelper(this);
        render();
    }

    private void render() {
        while (list.getChildCount() > 2) list.removeViewAt(2);
        Cursor c = db.getAllTests();
        if (!c.moveToFirst()) {
            LinearLayout empty = card();
            empty.addView(title("Kayıt yok", 18));
            empty.addView(body("Test sonucu ekleyince tüm kayıtların burada görünür."));
            list.addView(empty); c.close(); return;
        }
        int no = 1;
        do {
            int id=c.getInt(0); String source=c.getString(1); int testNo=c.getInt(2); String topic=c.getString(3); int d=c.getInt(4), y=c.getInt(5), e=c.getInt(6);
            int total=d+y+e; float net=d-(y/4f); int success=total==0?0:Math.round(d*100f/total);
            LinearLayout card = card();
            card.addView(title(no++ + ") " + (source==null?"Bağımsız test":source) + (testNo>0?" · Test "+testNo:""), 16));
            card.addView(body((topic==null?"Genel":topic) + "\nDoğru: " + d + " | Yanlış: " + y + " | Boş: " + e + "\nNet: " + String.format(Locale.US,"%.2f",net) + " | Başarı: %" + success));
            card.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Test kaydı")
                    .setMessage("Bu kaydı silmek istiyor musun?")
                    .setPositiveButton("Sil", (dialog, which) -> { db.deleteTestById(id); Toast.makeText(this,"Test silindi.",Toast.LENGTH_SHORT).show(); render(); })
                    .setNegativeButton("Vazgeç", null).show());
            list.addView(card);
        } while (c.moveToNext());
        c.close();
    }

    private LinearLayout card(){ LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(18),dp(18),dp(18)); card.setBackgroundResource(R.drawable.bg_card); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(12)); card.setLayoutParams(lp); return card; }
    private TextView title(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF0F172A); t.setTypeface(null, Typeface.BOLD); return t; }
    private TextView body(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(14); t.setTextColor(0xFF475569); t.setPadding(0,dp(8),0,0); t.setLineSpacing(4,1); return t; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    @Override public boolean onSupportNavigateUp(){ finish(); return true; }
}
