package com.beykent.akillitestanaliz;

import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class WrongBoxActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private LinearLayout list;
    private String current = "Çözülmedi";
    private EditText etSource, etTopic, etQuestionNo, etNote;
    private Button btnUnresolved, btnRepeat, btnSolved;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_wrong_box);
        if (getSupportActionBar()!=null) {
            getSupportActionBar().setTitle("Yanlış Kutusu");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = new DatabaseHelper(this);
        list = findViewById(R.id.layoutWrongList);
        etSource = findViewById(R.id.etWrongSource);
        etTopic = findViewById(R.id.etWrongTopic);
        etQuestionNo = findViewById(R.id.etWrongQuestionNo);
        etNote = findViewById(R.id.etWrongNote);

        btnUnresolved = findViewById(R.id.btnUnresolved);
        btnRepeat = findViewById(R.id.btnRepeat);
        btnSolved = findViewById(R.id.btnSolved);

        findViewById(R.id.btnAddWrong).setOnClickListener(v -> addWrong());

        btnUnresolved.setOnClickListener(v -> { current="Çözülmedi"; render(); });
        btnRepeat.setOnClickListener(v -> { current="Tekrar edilecek"; render(); });
        btnSolved.setOnClickListener(v -> { current="Çözüldü"; render(); });

        render();
    }

    private void addWrong() {
        String source = etSource.getText().toString().trim();
        String topic = etTopic.getText().toString().trim();
        String note = etNote.getText().toString().trim();

        int q = 0;
        try {
            String s = etQuestionNo.getText().toString().trim();
            if (!s.isEmpty()) q = Integer.parseInt(s);
        } catch(Exception e) {
            toast("Soru no sayı olmalı.");
            return;
        }

        if (topic.isEmpty()) {
            toast("Konu girmelisin.");
            return;
        }

        db.insertWrong(
                source.isEmpty() ? "Bağımsız kaynak" : source,
                topic,
                q,
                "Çözülmedi",
                note.isEmpty() ? "Manuel eklendi" : note
        );

        etSource.setText("");
        etTopic.setText("");
        etQuestionNo.setText("");
        etNote.setText("");

        current = "Çözülmedi";
        render();
        toast("Yanlış kaydedildi.");
    }

    private void render() {
        updateTabs();
        list.removeAllViews();

        Cursor c = db.getWrongByStatus(current);
        if (!c.moveToFirst()) {
            addEmpty();
            c.close();
            return;
        }

        do {
            addItem(c);
        } while(c.moveToNext());

        c.close();
    }

    private void updateTabs() {
        styleTab(btnUnresolved, current.equals("Çözülmedi"));
        styleTab(btnRepeat, current.equals("Tekrar edilecek"));
        styleTab(btnSolved, current.equals("Çözüldü"));
    }

    private void styleTab(Button b, boolean selected) {
        b.setBackgroundResource(selected ? R.drawable.bg_primary_button : R.drawable.bg_secondary_button);
        b.setTextColor(selected ? 0xFFFFFFFF : 0xFF1D4ED8);
    }

    private void addEmpty() {
        LinearLayout card = card();
        card.addView(title(current + " listesi boş", 18));

        if (current.equals("Çözülmedi")) {
            card.addView(body("Yeni yanlış eklediğinde burada görünür. Her soru kendi kaydıyla ayrı takip edilir."));
        } else if (current.equals("Tekrar edilecek")) {
            card.addView(body("Tekrara aldığın sorular burada görünür. Hazır olduğunda yeniden çalışmaya alabilirsin."));
        } else {
            card.addView(body("Çözdüğün yanlışlar burada saklanır."));
        }

        list.addView(card);
    }

    private void addItem(Cursor c) {
        final int id = c.getInt(0);
        String src = safe(c.getString(1), "Bağımsız kaynak");
        String topic = safe(c.getString(2), "Genel");
        String note = safe(c.getString(8), "");
        int questionNo = c.getInt(3);

        boolean tried = c.getInt(5) == 1;
        boolean video = c.getInt(6) == 1;
        boolean teacher = c.getInt(7) == 1;

        int step = teacher ? 3 : (video ? 2 : (tried ? 1 : 0));

        LinearLayout card = card();
        card.addView(title(topic, 18));

        String q = questionNo > 0 ? "Soru: " + questionNo : "Soru no yok";
        String desc = src + "  •  " + q;
        if (!note.trim().isEmpty()) desc += "\n" + note;
        card.addView(body(desc));

        if (current.equals("Çözüldü")) {
            card.addView(badge("Durum: Çözüldü ✅"));
            card.addView(body("Bu yanlış kapatıldı. Artık aktif çalışma listesinde görünmez."));
            list.addView(card);
            return;
        }

        if (current.equals("Tekrar edilecek")) {
            card.addView(badge("Durum: Tekrar edilecek"));
            card.addView(body("Bu soruyu tekrar çöz. Yapabiliyorsan çözüldü yap, zorlanıyorsan çalışmaya geri al."));

            LinearLayout row = row();
            row.addView(actionPrimary("Yeniden çalış", () -> {
                db.updateWrongStatus(id, "Çözülmedi");
                render();
            }));
            row.addView(actionSecondary("Çözüldü", () -> {
                db.markWrongSolved(id);
                render();
            }));
            card.addView(row);
            list.addView(card);
            return;
        }

        card.addView(badge(statusText(step)));
        card.addView(body(helpText(step)));

        if (step <= 0) {
            card.addView(actionPrimary("Kendim denedim", () -> {
                db.setWrongCurrentStep(id, 1);
                render();
            }), fullButtonLp());

            LinearLayout row = row();
            row.addView(actionSecondary("Tekrara al", () -> {
                db.updateWrongStatus(id, "Tekrar edilecek");
                render();
            }));
            card.addView(row);
        } else if (step == 1) {
            card.addView(actionPrimary("Videoya geç", () -> {
                db.setWrongCurrentStep(id, 2);
                render();
            }), fullButtonLp());

            LinearLayout row = row();
            row.addView(actionSecondary("Çözüldü", () -> {
                db.markWrongSolved(id);
                render();
            }));
            row.addView(actionSecondary("Tekrara al", () -> {
                db.updateWrongStatus(id, "Tekrar edilecek");
                render();
            }));
            card.addView(row);
        } else if (step == 2) {
            card.addView(actionPrimary("Hocaya geç", () -> {
                db.setWrongCurrentStep(id, 3);
                render();
            }), fullButtonLp());

            LinearLayout row = row();
            row.addView(actionSecondary("Çözüldü", () -> {
                db.markWrongSolved(id);
                render();
            }));
            row.addView(actionSecondary("Tekrara al", () -> {
                db.updateWrongStatus(id, "Tekrar edilecek");
                render();
            }));
            card.addView(row);
        } else {
            LinearLayout row = row();
            row.addView(actionPrimary("Çözüldü", () -> {
                db.markWrongSolved(id);
                render();
            }));
            row.addView(actionSecondary("Tekrara al", () -> {
                db.updateWrongStatus(id, "Tekrar edilecek");
                render();
            }));
            card.addView(row);
        }

        list.addView(card);
    }

    private String statusText(int step) {
        if (step <= 0) return "Durum: Çözülmedi";
        if (step == 1) return "Durum: Kendim denedim";
        if (step == 2) return "Durum: Video aşamasında";
        return "Durum: Hoca aşamasında";
    }

    private String helpText(int step) {
        if (step <= 0) return "Önce kendin çözmeyi dene. Yapamazsan sıradaki adıma geç.";
        if (step == 1) return "Kendin denedin. Anladıysan çözüldü yap, anlamadıysan videoya geç.";
        if (step == 2) return "Video aşamasındasın. Videodan anladıysan çözüldü yap, anlamadıysan hocaya geç.";
        return "Hoca aşamasındasın. Hâlâ oturmadıysa tekrara al, anladıysan çözüldü yap.";
    }

    private String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(8), 0, 0);
        return r;
    }

    private LinearLayout.LayoutParams fullButtonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.setMargins(0, dp(8), 0, 0);
        return lp;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackgroundResource(R.drawable.bg_card);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);
        return card;
    }

    private TextView title(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFF0F172A);
        t.setTextSize(size);
        t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView body(String s) {
        TextView b = new TextView(this);
        b.setText(s);
        b.setTextColor(0xFF64748B);
        b.setTextSize(13);
        b.setPadding(0, dp(6), 0, dp(8));
        b.setLineSpacing(4, 1);
        return b;
    }

    private TextView badge(String s) {
        TextView b = body(s);
        b.setTextColor(0xFF1D4ED8);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_secondary_button);
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        return b;
    }

    private TextView actionPrimary(String s, Runnable r) {
        TextView b = actionBase(s, r);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundResource(R.drawable.bg_primary_button);
        return b;
    }

    private TextView actionSecondary(String s, Runnable r) {
        TextView b = actionBase(s, r);
        b.setTextColor(0xFF1D4ED8);
        b.setBackgroundResource(R.drawable.bg_secondary_button);
        return b;
    }

    private TextView actionBase(String s, Runnable r) {
        TextView b = new TextView(this);
        b.setText(s);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextSize(13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1);
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> r.run());
        return b;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    @Override public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
