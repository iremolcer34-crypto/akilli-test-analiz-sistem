package com.beykent.akillitestanaliz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnBasla;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView txtQuote = findViewById(R.id.txtDailyMotivation);
        if (txtQuote != null) {
            String[] quotes = new String[]{
                    "Bugün küçük bir tekrar, yarın büyük bir net artışı getirir.",
                    "Zorlandığın konu düşmanın değil, çalışma planının pusulasıdır.",
                    "Bir yanlış kapatmak, bazen bir konuyu tamamen öğrenmek demektir.",
                    "Bugünün hedefi mükemmel olmak değil, dünden daha düzenli olmak.",
                    "Net artışı rastgele değil; kayıt, analiz ve tekrar ile gelir."
            };
            int index = (int) ((System.currentTimeMillis() / 86400000L) % quotes.length);
            txtQuote.setText("💬 Günün sözü: " + quotes[index]);
        }

        // XML'deki butonunla eşleştiriyoruz
        btnBasla = findViewById(R.id.btnStart);

        btnBasla.setOnClickListener(v -> {
            // Dashboard ekranına geçiş
            Intent i = new Intent(MainActivity.this, DashboardActivity.class);
            startActivity(i);
            // Kullanıcı uygulamaya her seferinde giriş ekranıyla başlasın istemiyorsan,
            // finish() kullanman uygulamayı kapatıp açtığında Dashboar'a gitmesini sağlar.
            finish();
        });
    }
}