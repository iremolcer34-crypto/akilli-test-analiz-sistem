package com.beykent.akillitestanaliz;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.LinkedHashMap;
import java.util.Map;

public class TimePrefs {
    private static final String PREFS = "app_prefs";

    public static final String EXAM_TYT = "TYT";
    public static final String EXAM_AYT = "AYT";
    public static final String EXAM_LGS = "LGS";
    public static final String EXAM_KPSS = "KPSS";

    public static final String KEY_ACTIVE_EXAM = "active_exam_type";

    public static void setActiveExamType(Context c, String exam) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_ACTIVE_EXAM, normalizeExam(exam)).apply();
    }

    public static String getActiveExamType(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return normalizeExam(sp.getString(KEY_ACTIVE_EXAM, EXAM_TYT));
    }

    public static String normalizeExam(String raw) {
        if (raw == null) return EXAM_TYT;
        String t = raw.trim().toUpperCase(new java.util.Locale("tr", "TR"));
        if (t.contains("YKS") || t.contains("AYT")) return EXAM_AYT;
        if (t.contains("LGS")) return EXAM_LGS;
        if (t.contains("KPSS")) return EXAM_KPSS;
        if (t.contains("TYT")) return EXAM_TYT;
        return t.length() == 0 ? EXAM_TYT : t;
    }

    // TYT/LGS
    public static final String L_TURKCE = "TURKCE";
    public static final String L_MAT = "MAT";
    public static final String L_SOS = "SOS";
    public static final String L_FEN = "FEN";

    // AYT
    public static final String L_EDEB = "EDEB";
    public static final String L_MAT2 = "MAT2";
    public static final String L_AYT_SOS = "AYT_SOS";
    public static final String L_AYT_FEN = "AYT_FEN";

    // KPSS
    public static final String L_GY = "GY";
    public static final String L_GK = "GK";
    public static final String L_EGITIM = "EGITIM";
    public static final String L_ALAN = "ALAN";

    private static String key(String exam, String lesson) {
        return "MIN_" + exam + "_" + lesson;
    }

    public static void putMinutes(Context c, String exam, String lesson, int minutes) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putInt(key(exam, lesson), clamp(minutes)).apply();
    }

    public static int getMinutes(Context c, String exam, String lesson, int def) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getInt(key(exam, lesson), def);
    }

    public static Map<String, Integer> getLessonMinutes(Context c, String exam) {
        LinkedHashMap<String, Integer> map = new LinkedHashMap<>();

        if (EXAM_TYT.equals(exam)) {
            map.put(L_TURKCE, getMinutes(c, exam, L_TURKCE, 55));
            map.put(L_MAT,    getMinutes(c, exam, L_MAT,    75));
            map.put(L_SOS,    getMinutes(c, exam, L_SOS,    25));
            map.put(L_FEN,    getMinutes(c, exam, L_FEN,    35));
        } else if (EXAM_AYT.equals(exam)) {
            map.put(L_EDEB,    getMinutes(c, exam, L_EDEB,    60));
            map.put(L_MAT2,    getMinutes(c, exam, L_MAT2,    80));
            map.put(L_AYT_SOS, getMinutes(c, exam, L_AYT_SOS, 40));
            map.put(L_AYT_FEN, getMinutes(c, exam, L_AYT_FEN, 40));
        } else if (EXAM_LGS.equals(exam)) {
            map.put(L_TURKCE, getMinutes(c, exam, L_TURKCE, 50));
            map.put(L_MAT,    getMinutes(c, exam, L_MAT,    60));
            map.put(L_SOS,    getMinutes(c, exam, L_SOS,    30));
            map.put(L_FEN,    getMinutes(c, exam, L_FEN,    40));
        } else { // KPSS
            map.put(L_GY,     getMinutes(c, exam, L_GY,     60));
            map.put(L_GK,     getMinutes(c, exam, L_GK,     60));
            map.put(L_EGITIM, getMinutes(c, exam, L_EGITIM, 75));
            map.put(L_ALAN,   getMinutes(c, exam, L_ALAN,   90));
        }

        return map;
    }

    public static int getTotalMinutes(Context c, String exam) {
        int total = 0;
        for (int v : getLessonMinutes(c, exam).values()) total += v;
        return total;
    }

    public static String label(String lessonKey) {
        switch (lessonKey) {
            case L_TURKCE: return "Türkçe";
            case L_MAT: return "Mat";
            case L_SOS: return "Sos";
            case L_FEN: return "Fen";
            case L_EDEB: return "Edebiyat";
            case L_MAT2: return "Mat-2";
            case L_AYT_SOS: return "Sosyal";
            case L_AYT_FEN: return "Fen";
            case L_GY: return "Genel Yetenek";
            case L_GK: return "Genel Kültür";
            case L_EGITIM: return "Eğitim Bilimleri";
            case L_ALAN: return "Alan Bilgisi";
            default: return lessonKey;
        }
    }

    private static int clamp(int v) {
        if (v < 0) return 0;
        if (v > 300) return 300;
        return v;
    }
}
