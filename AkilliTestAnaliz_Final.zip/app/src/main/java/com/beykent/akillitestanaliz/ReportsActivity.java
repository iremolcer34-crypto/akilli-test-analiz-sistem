package com.beykent.akillitestanaliz;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class ReportsActivity extends AppCompatActivity {
    private LinearLayout layoutMain;
    private DatabaseHelper dbHelper;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_reports);
        if (getSupportActionBar()!=null) { getSupportActionBar().setTitle("Detaylı Analiz"); getSupportActionBar().setDisplayHomeAsUpEnabled(true); }
        layoutMain=findViewById(R.id.layoutUniteList); dbHelper=new DatabaseHelper(this);
    }
    @Override protected void onResume(){ super.onResume(); render(); }

    private void render(){
        if (layoutMain.getChildCount() > 2) layoutMain.removeViews(2, layoutMain.getChildCount()-2);
        int d=dbHelper.getCountByStatus(DatabaseHelper.COL_CORRECT), y=dbHelper.getCountByStatus(DatabaseHelper.COL_WRONG), e=dbHelper.getCountByStatus(DatabaseHelper.COL_EMPTY);
        int total=d+y+e; int basari=total==0?0:(int)(d*100f/total); float lastNet=dbHelper.getLastExamNet(); int tests=dbHelper.getSolvedTestCount(); int exams=dbHelper.getExamCount();

        addHero("Genel Performans", "Başarı: %"+basari, "Çözülen test: "+tests+" | Deneme: "+exams+"\nToplam soru: "+total+"\nDoğru: "+d+" | Yanlış: "+y+" | Boş: "+e+"\nSon deneme neti: "+String.format(Locale.US,"%.2f",lastNet)+"\nSeviye: "+performanceLabel(basari)+" | Risk: "+riskLabel(y,e));
        addHeader("Koç Paneli");
        addCard("Öncelik Sırası", buildCoach(total,d,y,e,lastNet), false, null);
        addCard("Güçlü / Zayıf Ders", "En güçlü ders: "+dbHelper.getStrongestSubjectName()+"\nÖncelik verilecek ders: "+dbHelper.getWeakestSubjectName()+"\nKural: Zayıf ders → konu tekrar → video → yanlış kutusu → mini test.", false, null);
        addCard("Yanlış Kutusu Durumu", "Çözülmedi: "+dbHelper.getWrongCountByStatus("Çözülmedi")+"\nTekrar edilecek: "+dbHelper.getWrongCountByStatus("Tekrar edilecek")+"\nÇözüldü: "+dbHelper.getWrongCountByStatus("Çözüldü")+"\nHedef: Çözülmedi listesini her gün sıfıra yaklaştır.", false, null);
        addCard("Haftalık Aksiyon Planı", buildActionPlan(), false, null);

        addHeader("Deneme Trend ve Sıralama Analizi");
        renderExamAnalysis();
        addHeader("Son Test Geçmişi");
        renderRecentTests();
        addHeader("Ders Bazlı Test Analizi");
        renderSubjectAnalysis();
    }

    private String buildCoach(int total, int d, int y, int e, float lastNet) {
        if (total==0 && dbHelper.getExamCount()==0) return "Henüz veri yok. Önce test veya deneme ekle; analiz ekranı otomatik dolacak.";
        StringBuilder msg=new StringBuilder();
        int success=total==0?0:(int)(d*100f/total);
        if(success<50) msg.append("Başarı düşük. Rastgele test çözmek yerine 2 konu seçip kısa tekrar yap.\n");
        else if(success<70) msg.append("Orta seviye. Yanlış çıkan konularda tekrar + video + mini test yap.\n");
        else msg.append("Temel iyi. Net artırmak için boşları ve hız problemini hedefle.\n");
        if(y>e) msg.append("Yanlış sayısı boşlardan fazla: acele/konu eksiği var. Yanlış kutusu öncelik.\n");
        else if(e>0) msg.append("Boş sayısı var: süre yönetimi veya özgüven sorunu olabilir. Zamanlı test ekle.\n");
        if(lastNet>0) msg.append("Bir sonraki deneme hedefi: ").append(String.format(Locale.US,"%.2f",lastNet+3)).append(" net.");
        else msg.append("Deneme girmediğin için net trendi oluşmamış.");
        return msg.toString();
    }

    private void renderExamAnalysis() {
        int count=dbHelper.getExamCount();
        if (count==0) { addCard("Deneme verisi yok", "Deneme ekleyince burada son deneme, önceki deneme farkı, ders netleri, ders bazlı zayıf alanlar, tahmini sıralama/yüzdelik ve hedef önerisi görünür.", false, null); return; }

        Cursor trend = dbHelper.getExamTrend(6);
        StringBuilder trendLine = new StringBuilder();
        float last=-1, prev=-1, maxNet=1; int idx=0;
        java.util.ArrayList<String> names = new java.util.ArrayList<>();
        java.util.ArrayList<Float> nets = new java.util.ArrayList<>();
        while(trend.moveToNext()){
            if(idx==0) last=trend.getFloat(2); if(idx==1) prev=trend.getFloat(2);
            names.add(trend.getString(1)); nets.add(trend.getFloat(2)); maxNet=Math.max(maxNet, trend.getFloat(2)); idx++;
        }
        trend.close();
        for(int i=names.size()-1;i>=0;i--){
            trendLine.append(names.get(i)).append("\n")
                    .append(visualBar(nets.get(i), maxNet)).append("  ").append(fmt(nets.get(i))).append(" net\n");
        }
        String diff = prev>=0 ? String.format(Locale.US,"Son iki deneme farkı: %.2f net. ", last-prev) : "Trend için en az 2 deneme gerekli. ";
        addCard("Net Trend Özeti", diff + (prev>=0 && last>=prev ? "Yükseliş var; aynı tempoyu koru." : "Düşüş/eksik veri varsa önce yanlış kutusunu kapat.") + "\n\n" + trendLine, false, null);
        addChartCard("Görsel Net Trend", "Son denemelerin net değişimi. Çizgi yukarı gidiyorsa çalışma planı doğru yönde ilerliyor.", nets, names, MiniChartView.MODE_LINE);

        Cursor h=dbHelper.getExamHistory(); int i=0;
        if(h.moveToFirst()) {
            do {
                float tr=h.getFloat(3), sos=h.getFloat(4), mat=h.getFloat(5), fen=h.getFloat(6);
                String weakest=weakestBlock(tr,sos,mat,fen);
                addCard(h.getString(1)+" ("+h.getString(0)+")", "Toplam net: "+fmt(h.getFloat(2))+"\nTürkçe: "+fmt(tr)+" | Sosyal: "+fmt(sos)+"\nMatematik: "+fmt(mat)+" | Fen: "+fmt(fen)+"\nEn zayıf alan: "+weakest+"\n"+estimate(h.getString(0), h.getFloat(2))+"\nHedef: Bir sonraki denemede "+weakest+" alanından +2 net.", false, null);
                i++;
            } while(h.moveToNext() && i<5);
        }
        h.close();

        Cursor ls = dbHelper.getExamLessonStats();
        if(ls.moveToFirst()){
            StringBuilder sb = new StringBuilder(); int shown=0;
            do{
                String lesson=ls.getString(0); float d=ls.getFloat(1), y=ls.getFloat(2), e=ls.getFloat(3), net=ls.getFloat(4); int deneme=ls.getInt(5); float total=d+y+e; int success=total==0?0:Math.round(d*100f/total);
                sb.append("• ").append(lesson).append("\n")
                  .append("  Net: ").append(fmt(net)).append(" | Başarı: %").append(success).append(" | Yanlış: ").append((int)y).append("\n")
                  .append("  ").append(bar(success)).append("\n");
                shown++;
            }while(ls.moveToNext() && shown<10);
            addCard("Ders Bazlı Deneme Karnesi", sb.toString()+"\nEn güçlü deneme dersi: "+dbHelper.getStrongestExamLessonName()+"\nEn riskli deneme dersi: "+dbHelper.getWeakestExamLessonName(), false, null);
        }
        ls.close();

        addLessonWrongChart();

        Cursor wl = dbHelper.getWorstExamLessons(5);
        if(wl.moveToFirst()){
            StringBuilder risk = new StringBuilder(); int sira=1;
            do{
                String lesson=wl.getString(0); float d=wl.getFloat(1), y=wl.getFloat(2), e=wl.getFloat(3), net=wl.getFloat(4);
                float total=d+y+e; int success=total==0?0:Math.round(d*100f/total);
                risk.append(sira++).append(") ").append(lesson)
                        .append(" → Yanlış: ").append((int)y)
                        .append(" | Net: ").append(fmt(net))
                        .append(" | Başarı: %").append(success)
                        .append("\n   Aksiyon: 15 dk konu tekrar + 1 mini test + yanlış kutusu kontrolü.\n");
            }while(wl.moveToNext());
            addCard("Riskli Ders Öncelik Listesi", risk.toString(), false, null);
        }
        wl.close();
    }

    private void renderRecentTests(){
        Cursor c=dbHelper.getRecentTests(3);
        if(!c.moveToFirst()){ addCard("Test geçmişi yok", "Test sonucu ekleyince burada son 3 testin özet karnesi görünür. Eski kayıtlar ekranda birikmez; analiz hesaplarına dahil edilir.", false, null); c.close(); return; }
        StringBuilder sb = new StringBuilder();
        int count = 0, sumD = 0, sumY = 0, sumB = 0; float sumNet = 0;
        do{
            String source=c.getString(1); int no=c.getInt(2); String unite=c.getString(3); int d=c.getInt(4), y=c.getInt(5), b=c.getInt(6);
            int total=d+y+b; float net=d-(y/4f); int success=total==0?0:Math.round(d*100f/total);
            sumD += d; sumY += y; sumB += b; sumNet += net; count++;
            sb.append(count).append(") ").append(source==null?"Bağımsız test":source);
            if(no>0) sb.append(" · Test ").append(no);
            sb.append("\n   ").append(unite==null?"Genel":unite)
              .append(" | Net: ").append(fmt(net))
              .append(" | Başarı: %").append(success)
              .append(" | ").append(success>=70?"İyi":"Takip")
              .append("\n");
        }while(c.moveToNext());
        c.close();
        int total = sumD + sumY + sumB;
        int success = total==0 ? 0 : Math.round(sumD*100f/total);
        String header = "Son " + count + " test özeti";
        String body = "Toplam doğru: " + sumD + " | Yanlış: " + sumY + " | Boş: " + sumB +
                "\nOrtalama net: " + fmt(count==0?0:sumNet/count) + " | Genel başarı: %" + success +
                "\n\n" + sb +
                "\n\n🎯 Koç yorumu: Bu bölüm son 3 testi gösterir. Eski testler için ayrı geçmiş ekranını aç; analiz hesaplarına hepsi dahildir.";
        addCard(header, body, false, null);
        addHistoryButton();
    }

    private void addHistoryButton(){
        TextView b = new TextView(this);
        b.setText("Tüm test geçmişini gör");
        b.setGravity(android.view.Gravity.CENTER);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextSize(14);
        b.setTextColor(0xFF1D4ED8);
        b.setBackgroundResource(R.drawable.bg_secondary_button);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 52);
        lp.setMargins(0, 0, 0, 14);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> startActivity(new Intent(this, AllTestsActivity.class)));
        layoutMain.addView(b);
    }

    private void renderSubjectAnalysis(){
        java.util.LinkedHashSet<String> dersler = new java.util.LinkedHashSet<>();
        String aktifSinav = dbHelper.getActiveExamType();
        Cursor c1=dbHelper.getSubjectsByExamType(aktifSinav); while(c1.moveToNext()) { String d=c1.getString(0); if(d!=null && !d.trim().isEmpty()) dersler.add(d); } c1.close();
        if(dersler.isEmpty()){
            addCard("Ders analizi boş", dbHelper.getActiveExamType() + " için kitap ekleyip o kitaba bağlı test sonucu girince ders kartları açılır. Böylece TYT ve AYT/YKS verileri birbirine karışmaz.", false, null);
            return;
        }
        for(String ders: dersler){
            int[] o=dbHelper.getDersGenelOzet(ders); int t=o[0]+o[1]+o[2]; int p=t==0?0:(int)(o[0]*100f/t); String level=p>=75?"Güçlü":p>=50?"Orta":"Zayıf";
            addCard(ders+" · "+level, "Soru: "+t+" | Doğru: "+o[0]+" | Yanlış: "+o[1]+" | Boş: "+o[2]+"\nBaşarı: %"+p+"\nÖneri: "+miniAdvice(p,o[1],o[2])+"\nKonu detayları için dokun.", true, ders);
        }
    }


    private void addLessonWrongChart() {
        Cursor c = dbHelper.getWorstExamLessons(6);
        java.util.ArrayList<Float> values = new java.util.ArrayList<>();
        java.util.ArrayList<String> labels = new java.util.ArrayList<>();
        while (c.moveToNext()) {
            labels.add(c.getString(0));
            values.add(c.getFloat(2));
        }
        c.close();
        if (!values.isEmpty()) {
            addChartCard("Yanlış Yoğunluğu Grafiği", "En çok yanlış gelen dersler. En yüksek sütun, bugün ilk çalışılacak derstir.", values, labels, MiniChartView.MODE_BAR);
        }
    }

    private void addChartCard(String title, String body, java.util.ArrayList<Float> values, java.util.ArrayList<String> labels, int mode) {
        LinearLayout card = baseCard();
        card.addView(title(title,17));
        card.addView(body(body));
        MiniChartView chart = new MiniChartView(this);
        float[] data = new float[values.size()];
        String[] labs = new String[labels.size()];
        for (int i=0;i<values.size();i++) data[i] = values.get(i);
        for (int i=0;i<labels.size();i++) labs[i] = labels.get(i);
        chart.setData(data, labs, mode);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 12, 0, 0);
        chart.setLayoutParams(lp);
        card.addView(chart);
        layoutMain.addView(card);
    }

    private String visualBar(float value, float max) {
        int filled = value <= 0 ? 0 : Math.max(1, Math.min(20, Math.round((value / Math.max(1, max)) * 20f)));
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<20;i++) sb.append(i<filled ? "█" : "░");
        return sb.toString();
    }

    private String buildActionPlan(){
        return dbHelper.getDynamicWeeklyActionPlan();
    }

    private String bar(int percent){
        int filled = Math.max(0, Math.min(10, percent/10));
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<10;i++) sb.append(i<filled ? "█" : "░");
        return sb.toString();
    }

    private String weakestBlock(float tr,float sos,float mat,float fen){ float min=tr; String s="Türkçe"; if(sos<min){min=sos;s="Sosyal";} if(mat<min){min=mat;s="Matematik";} if(fen<min){min=fen;s="Fen";} return s; }
    private String miniAdvice(int success,int wrong,int empty){ if(success>=80) return "Güçlü. Hız ve zor soru çalış."; if(wrong>empty) return "Yanlış fazla. Çözüm incele, video/hoca adımı ekle."; return "Boşlar dikkat çekiyor. Süreli test ve temel konu tekrarı yap."; }
    private String performanceLabel(int success){ if(success>=80) return "Güçlü"; if(success>=60) return "Gelişiyor"; if(success>=40) return "Riskli"; return "Acil tekrar"; }
    private String riskLabel(int wrong,int empty){ if(wrong==0 && empty==0) return "Düşük"; if(wrong>empty) return "Yanlış ağırlıklı"; if(empty>0) return "Boş/süre ağırlıklı"; return "Takip"; }
    private String estimate(String type, float net) {
        if ("LGS".equals(type)) {
            String pct = net>=82 ? "%0.1 - %1.0" : net>=75 ? "%1 - %3" : net>=65 ? "%3 - %8" : net>=50 ? "%8 - %20" : "%20+";
            return "Yaklaşık LGS yüzdelik aralığı: " + pct + " (resmi değil, koçluk amaçlı)";
        }
        if ("TYT".equals(type)) {
            String band = net>=105 ? "çok güçlü / ilk 100 bin potansiyeli" : net>=90 ? "güçlü / 100-250 bin bandı" : net>=75 ? "orta-iyi / 250-500 bin bandı" : net>=55 ? "gelişiyor / 500 bin-1 milyon bandı" : "riskli / 1 milyon+ bandı";
            return "TYT başarı yorumu: " + band + " (TYT tek başına nihai YKS sıralaması değildir)";
        }
        if ("AYT".equals(type)) {
            String band = net>=65 ? "çok güçlü" : net>=50 ? "güçlü" : net>=35 ? "orta" : net>=20 ? "gelişiyor" : "riskli";
            return "Yaklaşık YKS başarı aralığı: " + band + " (resmi değil; TYT+AYT birlikte değerlendirilir)";
        }
        if ("KPSS".equals(type)) {
            String band = net>=95 ? "çok güçlü / üst sıralar" : net>=80 ? "güçlü / rekabetçi" : net>=65 ? "orta / yükseltilebilir" : net>=45 ? "riskli / konu eksiği var" : "acil temel tekrar";
            return "Yaklaşık KPSS başarı aralığı: " + band + " (resmi değil, koçluk amaçlı)";
        }
        return "Tahmini sonuç için veri birikmeli.";
    }
    private String fmt(float f){ return String.format(Locale.US,"%.2f",f); }
    private void addHeader(String t){ TextView v=new TextView(this); v.setText(t); v.setTextColor(0xFF0F172A); v.setTextSize(20); v.setTypeface(null,Typeface.BOLD); v.setPadding(0,20,0,10); layoutMain.addView(v); }
    private void addHero(String title,String metric,String body){ LinearLayout card=baseCard(); TextView a=title(title,18); TextView m=title(metric,26); m.setTextColor(0xFF2563EB); TextView b=body(body); card.addView(a); card.addView(m); card.addView(b); layoutMain.addView(card); }
    private void addCard(String title,String body,boolean clickable,String ders){ LinearLayout card=baseCard(); card.addView(title(title,17)); card.addView(body(body)); if(clickable){card.setOnClickListener(v->{Intent i=new Intent(this,ReportsDetailActivity.class); i.putExtra("ders_adi",ders); startActivity(i);});} layoutMain.addView(card); }
    private LinearLayout baseCard(){ LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackgroundResource(R.drawable.bg_card); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12); card.setLayoutParams(lp); return card; }
    private TextView title(String s,int size){ TextView a=new TextView(this); a.setText(s); a.setTextColor(0xFF0F172A); a.setTextSize(size); a.setTypeface(null,Typeface.BOLD); return a; }
    private TextView body(String s){ TextView b=new TextView(this); b.setText(s); b.setTextColor(0xFF475569); b.setTextSize(14); b.setPadding(0,8,0,0); b.setLineSpacing(3,1); return b; }
    @Override public boolean onSupportNavigateUp(){ finish(); return true; }
}
