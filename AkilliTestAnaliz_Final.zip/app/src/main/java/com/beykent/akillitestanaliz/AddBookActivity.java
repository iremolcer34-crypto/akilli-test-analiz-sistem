package com.beykent.akillitestanaliz;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddBookActivity extends AppCompatActivity {
    private EditText etBookName, etPublisher, etTotalTests;
    private Spinner spinnerExamType, spinnerLessons;
    private DatabaseHelper dbHelper;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_add_book);
        if (getSupportActionBar()!=null){ getSupportActionBar().setTitle("Kitap Ekle"); getSupportActionBar().setDisplayHomeAsUpEnabled(true); }
        dbHelper=new DatabaseHelper(this);
        etBookName=findViewById(R.id.etBookName); etPublisher=findViewById(R.id.etPublisher); etTotalTests=findViewById(R.id.etTotalTests);
        spinnerExamType=findViewById(R.id.spinnerExamType); spinnerLessons=findViewById(R.id.spinnerLessons); Button btn=findViewById(R.id.btnSaveBook);
        spinnerExamType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"TYT","AYT","LGS","KPSS","Diğer"}));
        spinnerLessons.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Türkçe","Matematik","Geometri","Fizik","Kimya","Biyoloji","Tarih","Coğrafya","Felsefe","Din Kültürü","Edebiyat","Sosyal","Fen","İngilizce"}));
        btn.setOnClickListener(v -> saveBook());
    }
    private void saveBook(){
        String name=etBookName.getText().toString().trim(); String publisher=etPublisher.getText().toString().trim(); String totalStr=etTotalTests.getText().toString().trim();
        if(name.isEmpty()){ toast("Kitap adı boş olamaz."); return; }
        if(totalStr.isEmpty()){ toast("Toplam test sayısını gir. 10 sabitliği artık yok."); return; }
        int total; try{ total=Integer.parseInt(totalStr); }catch(Exception e){ toast("Toplam test sayısı sayı olmalı."); return; }
        if(total<=0 || total>500){ toast("Toplam test sayısı 1-500 arasında olmalı."); return; }
        String fullName = publisher.isEmpty()? name : name + " (" + publisher + ")";
        String selectedExam = spinnerExamType.getSelectedItem().toString();
        dbHelper.saveBook(fullName, spinnerLessons.getSelectedItem().toString(), selectedExam, total);
        dbHelper.setActiveExamType(selectedExam);
        toast("Kitap kaydedildi. İlerleme yüzdesi " + total + " teste göre hesaplanacak."); finish();
    }
    private void toast(String m){ Toast.makeText(this,m,Toast.LENGTH_LONG).show(); }
    @Override public boolean onSupportNavigateUp(){ finish(); return true; }
}
