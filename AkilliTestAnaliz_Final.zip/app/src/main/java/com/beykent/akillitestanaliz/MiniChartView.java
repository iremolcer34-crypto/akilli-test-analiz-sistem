package com.beykent.akillitestanaliz;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

public class MiniChartView extends View {
    public static final int MODE_LINE = 1;
    public static final int MODE_BAR = 2;

    private float[] values = new float[0];
    private String[] labels = new String[0];
    private int mode = MODE_LINE;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public MiniChartView(Context context) {
        super(context);
        textPaint.setTextSize(24f);
        textPaint.setColor(Color.rgb(100, 116, 139));
        setMinimumHeight(dp(180));
    }

    public void setData(float[] values, String[] labels, int mode) {
        this.values = values == null ? new float[0] : values;
        this.labels = labels == null ? new String[0] : labels;
        this.mode = mode;
        invalidate();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desiredHeight = dp(190);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        int left = dp(24), right = w - dp(24), top = dp(20), bottom = h - dp(38);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f);
        paint.setColor(Color.rgb(226, 232, 240));
        for (int i = 0; i < 4; i++) {
            float y = top + (bottom - top) * i / 3f;
            canvas.drawLine(left, y, right, y, paint);
        }

        if (values.length == 0) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Grafik için veri yok", w / 2f, h / 2f, textPaint);
            return;
        }

        float max = 1f;
        for (float v : values) max = Math.max(max, Math.abs(v));

        if (mode == MODE_BAR) drawBars(canvas, left, right, top, bottom, max);
        else drawLine(canvas, left, right, top, bottom, max);
    }

    private void drawLine(Canvas canvas, int left, int right, int top, int bottom, float max) {
        if (values.length == 1) {
            drawBars(canvas, left, right, top, bottom, max);
            return;
        }
        Path path = new Path();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(6f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(Color.rgb(37, 99, 235));

        for (int i = 0; i < values.length; i++) {
            float x = left + (right - left) * i / (float)(values.length - 1);
            float y = bottom - (Math.max(0, values[i]) / max) * (bottom - top);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        canvas.drawPath(path, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(37, 99, 235));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(18f);
        for (int i = 0; i < values.length; i++) {
            float x = left + (right - left) * i / (float)(values.length - 1);
            float y = bottom - (Math.max(0, values[i]) / max) * (bottom - top);
            canvas.drawCircle(x, y, dp(4), paint);
            if (i < labels.length) canvas.drawText(shortLabel(labels[i]), x, bottom + dp(26), textPaint);
        }
    }

    private void drawBars(Canvas canvas, int left, int right, int top, int bottom, float max) {
        int n = values.length;
        float gap = dp(10);
        float rawW = ((right - left) - gap * (n - 1)) / Math.max(1, n);
        float barW = Math.max(dp(18), Math.min(dp(62), rawW));
        float totalW = barW * n + gap * Math.max(0, n - 1);
        float startX = left + ((right - left) - totalW) / 2f;
        paint.setStyle(Paint.Style.FILL);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(18f);
        for (int i = 0; i < n; i++) {
            float x1 = startX + i * (barW + gap);
            float x2 = x1 + barW;
            float y1 = bottom - (Math.max(0, values[i]) / max) * (bottom - top);
            paint.setColor(Color.rgb(37, 99, 235));
            canvas.drawRoundRect(new RectF(x1, y1, x2, bottom), dp(8), dp(8), paint);
            if (i < labels.length) canvas.drawText(shortLabel(labels[i]), (x1 + x2) / 2f, bottom + dp(26), textPaint);
        }
    }

    private String shortLabel(String s) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= 6 ? s : s.substring(0, 6);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
