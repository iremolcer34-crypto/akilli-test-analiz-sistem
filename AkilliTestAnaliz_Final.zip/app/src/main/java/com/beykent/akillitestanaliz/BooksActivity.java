package com.beykent.akillitestanaliz;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class BooksActivity extends AppCompatActivity {

    private RecyclerView rvBooks;
    private View layoutEmptyState;
    private BookAdapter adapter;
    private List<Book> bookList;
    private DatabaseHelper dbHelper;
    private FloatingActionButton fabAddBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Kitaplarım");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        rvBooks = findViewById(R.id.rvBooks);
        layoutEmptyState = findViewById(R.id.layoutEmptyState);
        fabAddBook = findViewById(R.id.fabAddBook);

        dbHelper = new DatabaseHelper(this);
        bookList = new ArrayList<>();
        rvBooks.setLayoutManager(new LinearLayoutManager(this));

        // Hata vermemesi için AddBookActivity sınıfının mevcut olduğundan emin olun
        fabAddBook.setOnClickListener(v -> startActivity(new Intent(this, AddBookActivity.class)));

        loadBooks();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadBooks();
    }

    private void loadBooks() {
        bookList.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String activeType = dbHelper.getActiveExamType();
        Cursor cursor;
        if (TimePrefs.EXAM_AYT.equals(activeType)) {
            cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_BOOKS + " WHERE " + DatabaseHelper.COL_BOOK_EXAM_TYPE + " IN ('AYT','YKS')", null);
        } else {
            cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_BOOKS + " WHERE " + DatabaseHelper.COL_BOOK_EXAM_TYPE + "=?", new String[]{activeType});
        }

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BOOK_NAME));
                String subject = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BOOK_SUBJECT));
                int totalTests = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BOOK_TOTAL_TESTS));

                // Artık DatabaseHelper dosyanız bu metodu tanıyor
                int progress = dbHelper.getBookProgress(id);

                bookList.add(new Book(id, name, subject, totalTests, progress));
            } while (cursor.moveToNext());
            cursor.close();
        }

        updateUI();
    }

    private void updateUI() {
        if (bookList.isEmpty()) {
            rvBooks.setVisibility(View.GONE);
            layoutEmptyState.setVisibility(View.VISIBLE);
        } else {
            rvBooks.setVisibility(View.VISIBLE);
            layoutEmptyState.setVisibility(View.GONE);

            if (adapter == null) {
                adapter = new BookAdapter(bookList);
                rvBooks.setAdapter(adapter);
            } else {
                adapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}