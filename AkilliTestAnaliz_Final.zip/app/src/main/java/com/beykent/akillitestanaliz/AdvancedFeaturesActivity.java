package com.beykent.akillitestanaliz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class AdvancedFeaturesActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private LinearLayout root;
    private SharedPreferences prefs;
    private EditText edtWeeklyTestTarget, edtWeeklyHourTarget, edtReminderText;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DatabaseHelper(this);
        prefs = getSharedPreferences("coach_features", MODE_PRIVATE);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Gelişmiş Koçluk");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundResource(R.drawable.bg_app);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        root.setPadding(p, p, p, dp(28));
        scroll.addView(root);
        setContentView(scroll);

        addHeader("Gelişmiş Analiz ve Koçluk");
        addText("Hedef, konu stratejisi, grafik ve rapor çıktıları bu ekranda toplanır. Bu bölüm artık sadece sayı değil, çalışılacak yol haritası üretir.");
        renderExecutiveCoachCard();
        renderWeeklyGoal();
        renderSubjectStrategy();
        renderTopicAnalysis();
        renderProfessionalCharts();
        renderReminder();
        renderExport();
    }

    private void renderExecutiveCoachCard() {
        LinearLayout card = card();
        card.addView(title("Koçluk Özeti", 18));
        card.addView(body(db.buildDetailedCoachReport().split("DERS BAZLI ÇALIŞMA STRATEJİSİ")[0].trim()));
        root.addView(card);
    }

    private void renderWeeklyGoal() {
        LinearLayout card = card();
        card.addView(title("Haftalık Çalışma Hedefi", 18));
        int targetTests = prefs.getInt("target_tests", 25);
        int targetHours = prefs.getInt("target_hours", 10);
        int solvedThisWeek = db.getTestsThisWeek();
        int percent = targetTests == 0 ? 0 : Math.min(100, Math.round(solvedThisWeek * 100f / targetTests));
        card.addView(body("Bu hafta çözülen test: " + solvedThisWeek + " / " + targetTests + "\nHedef tamamlama: %" + percent + "\nSaat hedefi: " + targetHours + " saat\nÖneri: " + weeklyAdvice(percent)));
        card.addView(chart(new float[]{solvedThisWeek, Math.max(0, targetTests - solvedThisWeek)}, new String[]{"Bitti", "Kaldı"}, MiniChartView.MODE_BAR));

        card.addView(label("Haftalık test hedefi"));
        edtWeeklyTestTarget = input("Örn: 25", String.valueOf(targetTests));
        card.addView(edtWeeklyTestTarget);
        card.addView(label("Haftalık saat hedefi"));
        edtWeeklyHourTarget = input("Örn: 10", String.valueOf(targetHours));
        card.addView(edtWeeklyHourTarget);
        Button save = button("Hedefi Kaydet");
        save.setOnClickListener(v -> {
            prefs.edit()
                    .putInt("target_tests", safeInt(edtWeeklyTestTarget.getText().toString(), 25))
                    .putInt("target_hours", safeInt(edtWeeklyHourTarget.getText().toString(), 10))
                    .apply();
            Toast.makeText(this, "Haftalık hedef güncellendi", Toast.LENGTH_SHORT).show();
            buildUi();
        });
        card.addView(save);
        root.addView(card);
    }

    private void renderSubjectStrategy() {
        LinearLayout card = card();
        card.addView(title("Ders Bazlı Strateji", 18));
        Cursor c = db.getReadableDatabase().rawQuery("SELECT b."+DatabaseHelper.COL_BOOK_SUBJECT+", IFNULL(SUM(st."+DatabaseHelper.COL_CORRECT+"),0), IFNULL(SUM(st."+DatabaseHelper.COL_WRONG+"),0), IFNULL(SUM(st."+DatabaseHelper.COL_EMPTY+"),0) FROM "+DatabaseHelper.TABLE_SOLVED_TESTS+" st LEFT JOIN "+DatabaseHelper.TABLE_BOOKS+" b ON st."+DatabaseHelper.COL_SOLVED_BOOK_ID+"=b."+DatabaseHelper.COL_ID+" GROUP BY b."+DatabaseHelper.COL_BOOK_SUBJECT+" ORDER BY SUM(st."+DatabaseHelper.COL_WRONG+") DESC, SUM(st."+DatabaseHelper.COL_CORRECT+") ASC LIMIT 6", null);
        if (!c.moveToFirst()) {
            card.addView(body("Henüz ders bazlı strateji oluşmadı. Test eklerken ders/konu alanını doldur; sistem hangi derse nasıl çalışman gerektiğini çıkaracak."));
        } else {
            do {
                String subject = c.getString(0);
                if (subject == null || subject.trim().isEmpty()) subject = "Bağımsız Testler";
                int d = c.getInt(1), y = c.getInt(2), b = c.getInt(3);
                int total = d + y + b;
                int success = total == 0 ? 0 : Math.round(d * 100f / total);
                card.addView(strategyBox(subject, success, d, y, b, db.getSubjectStrategy(subject, success, y, b)));
            } while (c.moveToNext());
        }
        c.close();
        root.addView(card);
    }

    private void renderTopicAnalysis() {
        LinearLayout card = card();
        card.addView(title("Konu Bazlı Analiz", 18));
        Cursor c = db.getTopicPerformance(8);
        if (!c.moveToFirst()) {
            card.addView(body("Henüz konu/ünite verisi yok. Test sonucu girerken konu alanını doldurursan burada en riskli konular listelenir."));
        } else {
            StringBuilder sb = new StringBuilder();
            ArrayList<Float> wrongs = new ArrayList<>();
            ArrayList<String> labels = new ArrayList<>();
            int i = 1;
            do {
                String konu = c.getString(0);
                int d = c.getInt(1), y = c.getInt(2), bos = c.getInt(3), adet = c.getInt(4);
                int total = d + y + bos;
                int success = total == 0 ? 0 : Math.round(d * 100f / total);
                sb.append(i++).append(") ").append(konu).append(" → %").append(success)
                        .append(" başarı | Yanlış: ").append(y).append(" | Test: ").append(adet)
                        .append("\n   Aksiyon: ").append(topicAdvice(success, y, bos)).append("\n");
                wrongs.add((float)y);
                labels.add(konu);
            } while (c.moveToNext());
            card.addView(body(sb.toString()));
            card.addView(chart(toArray(wrongs), toLabels(labels), MiniChartView.MODE_BAR));
        }
        c.close();
        root.addView(card);
    }

    private void renderProfessionalCharts() {
        LinearLayout card = card();
        card.addView(title("Profesyonel Grafik Paneli", 18));
        Cursor exams = db.getExamHistoryFull(7);
        ArrayList<Float> nets = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        while (exams.moveToNext()) {
            nets.add(0, exams.getFloat(3));
            String nm = exams.getString(2);
            names.add(0, nm == null || nm.trim().isEmpty() ? "Deneme" : nm);
        }
        exams.close();
        if (nets.isEmpty()) {
            card.addView(body("Deneme ekledikçe net trendi burada çizgi grafik olarak oluşur."));
        } else {
            card.addView(body("Son denemelerin net trendi. Çizgi yukarı gidiyorsa tempo doğru; düşüyorsa yanlış kutusu ve zayıf konu çalışması artırılmalı."));
            card.addView(chart(toArray(nets), toLabels(names), MiniChartView.MODE_LINE));
        }
        root.addView(card);
    }

    private void renderReminder() {
        LinearLayout card = card();
        card.addView(title("Hatırlatma Sistemi", 18));
        String saved = prefs.getString("reminder_text", "Bugünkü test ve yanlış kutusu hedefini tamamla.");
        card.addView(body("Basit çalışma hatırlatıcısı. Kaydettiğinde uygulama içi koçluk metni saklanır; bildirim izni açıksa Android alarmı da planlanır."));
        edtReminderText = input("Hatırlatma metni", saved);
        card.addView(edtReminderText);
        Button save = button("Hatırlatmayı Kaydet ve Planla");
        save.setOnClickListener(v -> {
            String text = edtReminderText.getText().toString().trim();
            if (text.isEmpty()) text = "Bugünkü çalışma hedefini tamamla.";
            prefs.edit().putString("reminder_text", text).apply();
            scheduleReminder(text);
            Toast.makeText(this, "Hatırlatma kaydedildi", Toast.LENGTH_LONG).show();
        });
        card.addView(save);
        root.addView(card);
    }

    private void renderExport() {
        LinearLayout card = card();
        card.addView(title("PDF / Excel Rapor Dışa Aktarma", 18));
        card.addView(body("PDF artık yalnızca özet değil; genel performans, ders stratejisi, deneme analizi, konu riskleri ve koç önerilerini içerir. CSV dosyası Excel ile açılır ve detaylı analiz satırlarını içerir."));
        Button pdf = button("Detaylı PDF Rapor Oluştur");
        pdf.setOnClickListener(v -> exportPdf());
        Button csv = button("Detaylı Excel CSV Oluştur");
        csv.setOnClickListener(v -> exportCsv());
        card.addView(pdf);
        card.addView(csv);
        root.addView(card);
    }

    private void scheduleReminder(String text) {
        try {
            Intent i = new Intent(this, ReminderReceiver.class);
            i.putExtra("message", text);
            PendingIntent pi = PendingIntent.getBroadcast(this, 42, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60_000, pi);
        } catch (Exception ignored) { }
    }

    private void exportCsv() {
        try {
            String fileName = "akilli_test_analiz_detayli_rapor.csv";
            Uri uri = createDownloadFile(fileName, "text/csv");
            if (uri == null) throw new IllegalStateException("Dosya konumu oluşturulamadı");
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new IllegalStateException("Dosya açılamadı");
            out.write(db.buildExportCsv().getBytes(StandardCharsets.UTF_8));
            out.close();
            Toast.makeText(this, "CSV raporu oluşturuldu. Konum: Download/AkilliTestAnaliz/" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "CSV oluşturulamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void exportPdf() {
        PdfDocument doc = null;
        try {
            doc = new PdfDocument();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            int pageNo = 1;
            PdfDocument.Page page = newPage(doc, pageNo);
            Canvas canvas = page.getCanvas();
            int y = 48;
            y = drawTitle(canvas, paint, "Akıllı Test Analiz Detaylı Raporu", y);
            y = drawText(canvas, paint, "Rapor tarihi: " + new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(new Date()), 40, y, 12, false);
            y = drawText(canvas, paint, "Not: Tahmini sonuçlar resmi değildir; çalışma takibi ve koçluk amacıyla kullanılır.", 40, y + 8, 12, false);
            y += 12;

            String[] lines = db.buildExportSummary().split("\\n");
            for (String line : lines) {
                if (y > 790) {
                    doc.finishPage(page);
                    pageNo++;
                    page = newPage(doc, pageNo);
                    canvas = page.getCanvas();
                    y = 48;
                }
                boolean heading = line.equals(line.toUpperCase(Locale.ROOT)) && line.trim().length() > 3;
                y = drawText(canvas, paint, line, 40, y, heading ? 14 : 11, heading);
                y += heading ? 8 : 3;
            }
            doc.finishPage(page);

            String fileName = "akilli_test_analiz_detayli_rapor.pdf";
            Uri uri = createDownloadFile(fileName, "application/pdf");
            if (uri == null) throw new IllegalStateException("Dosya konumu oluşturulamadı");
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) throw new IllegalStateException("Dosya açılamadı");
            doc.writeTo(out);
            out.close();
            doc.close();
            Toast.makeText(this, "PDF raporu oluşturuldu. Konum: Download/AkilliTestAnaliz/" + fileName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            if (doc != null) try { doc.close(); } catch (Exception ignored) {}
            Toast.makeText(this, "PDF oluşturulamadı: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private PdfDocument.Page newPage(PdfDocument doc, int pageNo) {
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNo).create();
        return doc.startPage(info);
    }

    private int drawTitle(Canvas canvas, Paint paint, String text, int y) {
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(19f);
        paint.setColor(0xFF0F172A);
        canvas.drawText(text, 40, y, paint);
        return y + 34;
    }

    private int drawText(Canvas canvas, Paint paint, String text, int x, int y, int size, boolean bold) {
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL));
        paint.setTextSize(size);
        paint.setColor(bold ? 0xFF0F172A : 0xFF334155);
        if (text == null) text = "";
        int max = 82;
        String remaining = text;
        while (remaining.length() > max) {
            int cut = remaining.lastIndexOf(' ', max);
            if (cut <= 0) cut = max;
            canvas.drawText(remaining.substring(0, cut), x, y, paint);
            y += size + 7;
            remaining = remaining.substring(cut).trim();
        }
        canvas.drawText(remaining, x, y, paint);
        return y + size + 8;
    }

    private Uri createDownloadFile(String fileName, String mimeType) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AkilliTestAnaliz");
            return getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "AkilliTestAnaliz");
            if (!dir.exists()) dir.mkdirs();
            return Uri.fromFile(new File(dir, fileName));
        }
    }

    private LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18), dp(18), dp(18), dp(18)); l.setBackgroundResource(R.drawable.bg_card); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(14)); l.setLayoutParams(lp); return l; }
    private TextView title(String s, int size) { TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(0xFF0F172A); v.setTypeface(null, Typeface.BOLD); return v; }
    private TextView label(String s) { TextView v = new TextView(this); v.setText(s); v.setTextSize(13); v.setTextColor(0xFF1E293B); v.setTypeface(null, Typeface.BOLD); v.setPadding(0, dp(10), 0, 0); return v; }
    private void addHeader(String s) { TextView v = title(s, 24); v.setPadding(0, 0, 0, dp(6)); root.addView(v); }
    private void addText(String s) { TextView v = body(s); v.setPadding(0, 0, 0, dp(16)); root.addView(v); }
    private TextView body(String s) { TextView v = new TextView(this); v.setText(s); v.setTextSize(14); v.setTextColor(0xFF475569); v.setLineSpacing(4, 1); v.setPadding(0, dp(8), 0, dp(8)); return v; }
    private EditText input(String hint, String text) { EditText e = new EditText(this); e.setHint(hint); e.setText(text); e.setSingleLine(false); e.setMinHeight(dp(52)); e.setBackgroundResource(R.drawable.bg_input); e.setPadding(dp(14), 0, dp(14), 0); e.setTextColor(0xFF0F172A); e.setHintTextColor(0xFF94A3B8); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(8), 0, dp(8)); e.setLayoutParams(lp); return e; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52)); lp.setMargins(0, dp(8), 0, 0); b.setLayoutParams(lp); return b; }
    private MiniChartView chart(float[] data, String[] labels, int mode) { MiniChartView v = new MiniChartView(this); v.setData(data, labels, mode); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(10), 0, 0); v.setLayoutParams(lp); return v; }
    private TextView strategyBox(String subject, int success, int d, int y, int b, String strategy) { TextView v = body(subject + "\nBaşarı: %" + success + " | Doğru: " + d + " | Yanlış: " + y + " | Boş: " + b + "\nStrateji: " + strategy); v.setBackgroundResource(R.drawable.bg_input); v.setPadding(dp(14), dp(12), dp(14), dp(12)); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(10), 0, 0); v.setLayoutParams(lp); return v; }
    private float[] toArray(ArrayList<Float> list) { float[] a = new float[list.size()]; for (int i=0;i<list.size();i++) a[i]=list.get(i); return a; }
    private String[] toLabels(ArrayList<String> list) { String[] a = new String[list.size()]; for (int i=0;i<list.size();i++) a[i]=list.get(i); return a; }
    private int safeInt(String s, int def) { try { return Math.max(0, Integer.parseInt(s.trim())); } catch(Exception e) { return def; } }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private String weeklyAdvice(int p) { if (p >= 100) return "Hedef tamam. Bugün yanlış kutusu kapatma günü."; if (p >= 70) return "İyi gidiyorsun. Kalan testleri zayıf konulardan seç."; return "Tempo düşük. Günlük hedefi küçük parçalara böl: 2 test + 20 dk tekrar."; }
    private String topicAdvice(int success, int wrong, int empty) { if (success >= 80) return "Zor soru ve süre çalış."; if (wrong > empty) return "Çözüm izle + hocaya sor + benzer 10 soru."; return "Temel konu tekrarı + süreli mini test."; }
    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
