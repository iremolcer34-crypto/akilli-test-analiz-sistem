package com.beykent.akillitestanaliz.data.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.beykent.akillitestanaliz.data.dao.PublisherDao;
import com.beykent.akillitestanaliz.data.entity.Publisher;

@Database(entities = {Publisher.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract PublisherDao publisherDao();

    private static AppDatabase INSTANCE;

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "akilli_test_db"
            ).allowMainThreadQueries().build();
        }
        return INSTANCE;
    }
}
