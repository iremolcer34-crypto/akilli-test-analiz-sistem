package com.beykent.akillitestanaliz;

public class Test {
    public int id, bookId, testNo, correct, wrong, empty;
    public String unite;

    public Test(int id, int bookId, int testNo, String unite, int correct, int wrong, int empty) {
        this.id = id;
        this.bookId = bookId;
        this.testNo = testNo;
        this.unite = unite;
        this.correct = correct;
        this.wrong = wrong;
        this.empty = empty;
    }
}