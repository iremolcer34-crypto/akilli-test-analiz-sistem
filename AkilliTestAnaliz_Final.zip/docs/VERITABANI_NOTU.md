# Veritabanı Notu

Uygulamanın aktif veri akışı SQLiteOpenHelper tabanlı `DatabaseHelper` sınıfı üzerinden çalışır.

Projede Room dosyaları da bulunur; ancak bu sürümde ana çalışan mimari SQLite tarafıdır. Room yapısı ileri geliştirme ve migration planı için taslak olarak bırakılmıştır.

Sunumda doğru anlatım:
> Bu sürümde kalıcı veri yönetimi SQLite ile sağlandı. Room katmanı ise ikinci dönem geliştirilecek daha modern mimari için temel olarak eklendi.
