# TYT / AYT-YKS Veri Ayrıştırma Güncellemesi

Bu güncellemede koçluk ve raporlama hesapları genel havuzdan çıkarıldı. Sistem artık aktif sınav türüne göre çalışır.

## Mantık
- TYT kitabı yalnızca TYT analizine dahil edilir.
- AYT/YKS kitabı yalnızca AYT analizine dahil edilir.
- TYT denemesi yalnızca TYT net trendinde kullanılır.
- AYT denemesi yalnızca AYT/YKS net trendinde kullanılır.
- Dashboard, rapor ve koçluk mesajı aktif sınav türünü ayrı gösterir.

## Kod tarafında değişen ana noktalar
- DatabaseHelper içinde `getActiveExamType()` eklendi.
- `getCountByStatus`, `getSolvedTestCount`, `getExamCount`, `getRecentTests`, `getTopicPerformance`, `getDersGenelOzet`, `getUniteOzetiByDers` filtreli hale getirildi.
- ReportsActivity ders analizinde artık tüm sınav türleri toplanmıyor; yalnızca aktif sınav türünün dersleri listeleniyor.
- DashboardActivity özetinde aktif sınav türü açıkça yazıyor.

## Neden gerekliydi?
TYT ve AYT/YKS farklı sınav yapısına sahiptir. Bu yüzden aynı başarı yüzdesinde toplanırsa koçluk önerisi yanlış olur. Örneğin TYT Türkçe başarısı ile AYT Biyoloji zayıflığı aynı havuzda değerlendirilirse sistem öğrencinin asıl önceliğini yanlış seçebilir.
