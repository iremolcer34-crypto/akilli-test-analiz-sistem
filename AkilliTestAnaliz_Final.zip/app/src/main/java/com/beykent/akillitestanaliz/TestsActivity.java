package com.beykent.akillitestanaliz;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.Locale;

public class TestsActivity extends AppCompatActivity {
    private AutoCompleteTextView etBookName;
    private EditText etTestNo, etUnite, etSoruNo, etCorrect, etWrong, etEmpty;
    private TextView txtInfo;
    private LinearLayout layoutHistory;
    private DatabaseHelper dbHelper;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tests);
        if(getSupportActionBar()!=null){getSupportActionBar().setTitle("Test Sonucu Ekle");getSupportActionBar().setDisplayHomeAsUpEnabled(true);}
        dbHelper=new DatabaseHelper(this);
        etBookName=findViewById(R.id.etBookName); etTestNo=findViewById(R.id.etTestNo); etUnite=findViewById(R.id.etUnite); etSoruNo=findViewById(R.id.etSoruNo);
        etCorrect=findViewById(R.id.etCorrect); etWrong=findViewById(R.id.etWrong); etEmpty=findViewById(R.id.etEmpty); txtInfo=findViewById(R.id.txtTestInfo);
        layoutHistory=findViewById(R.id.layoutTestHistory);
        List<String> publishers=dbHelper.getAllPublishers(); etBookName.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, publishers));
        findViewById(R.id.btnSaveTest).setOnClickListener(v -> saveTestResult());
        findViewById(R.id.btnAllTests).setOnClickListener(v -> startActivity(new Intent(this, AllTestsActivity.class)));
        renderHistory();
    }

    @Override protected void onResume(){ super.onResume(); renderHistory(); }

    private void saveTestResult(){
        String source=etBookName.getText().toString().trim();
        String testNoStr=etTestNo.getText().toString().trim();
        String unite=etUnite.getText().toString().trim();
        String totalStr=etSoruNo.getText().toString().trim();
        if(unite.isEmpty()) unite="Genel";
        if(totalStr.isEmpty()){toast("Toplam soru sayısı gerekli.");return;}
        int total,d,y,b,testNo=0;
        try{ total=Integer.parseInt(totalStr); d=parse(etCorrect); y=parse(etWrong); b=parse(etEmpty); if(!testNoStr.isEmpty()) testNo=Integer.parseInt(testNoStr);}catch(Exception e){toast("Sayı alanlarını kontrol et.");return;}
        if(total<=0 || total>300){toast("Toplam soru 1-300 arasında olmalı.");return;}
        if(d<0||y<0||b<0){toast("Negatif değer girilemez.");return;}
        if(d+y+b>total){toast("Doğru + yanlış + boş toplam soruyu geçemez.");return;}
        if(d+y+b<total){toast("Eksik giriş var: Doğru + yanlış + boş toplam soruya eşit olmalı.");return;}
        int bookId = source.isEmpty()? -1 : dbHelper.getBookIdByName(source);
        if(!source.isEmpty() && bookId==-1) bookId=-1;
        String finalSource = source.isEmpty()?"Bağımsız / öğretmen testi":source;
        dbHelper.saveAnyTestResult(bookId, testNo, finalSource, unite, d, y, b);
        float net=d-(y/4f);
        txtInfo.setText(String.format(Locale.US,"Kaydedildi. Net: %.2f | Form temizlendi, yeni test girebilirsin.", net));
        clearAfterSave();
        renderHistory();
    }

    private void clearAfterSave(){
        etBookName.setText("");
        etTestNo.setText(""); etUnite.setText(""); etSoruNo.setText(""); etCorrect.setText(""); etWrong.setText(""); etEmpty.setText("");
        etBookName.requestFocus();
    }

    private void renderHistory(){
        if(layoutHistory==null) return;
        layoutHistory.removeAllViews();
        TextView summary = new TextView(this);
        summary.setText("Burada sadece son 5 kayıt görünür. Tüm eski testler için alttaki butonu kullan.");
        summary.setTextSize(13); summary.setTextColor(0xFF64748B); summary.setPadding(0,0,0,12);
        layoutHistory.addView(summary);
        Cursor c=dbHelper.getRecentTests(5);
        if(!c.moveToFirst()){
            addHistoryCard("Henüz test geçmişi yok", "Kaydettiğin son 5 test burada görünecek. Tüm veriler analiz ekranında özetlenir.", false);
            c.close(); return;
        }
        do{
            int id=c.getInt(0); String source=c.getString(1); int no=c.getInt(2); String unite=c.getString(3); int d=c.getInt(4), y=c.getInt(5), b=c.getInt(6);
            int total=d+y+b; float net=d-(y/4f); int success=total==0?0:Math.round(d*100f/total);
            String title=(source==null?"Bağımsız test":source) + (no>0?" · Test "+no:" · Test no yok");
            String body=unite+"\nDoğru: "+d+" | Yanlış: "+y+" | Boş: "+b+" | Net: "+String.format(Locale.US,"%.2f",net)+" | Başarı: %"+success+"\nDokun: Güncelle / Sil";
            addHistoryCard(id, source, no, unite, d, y, b, title, body, success>=70);
        }while(c.moveToNext());
        c.close();
    }

    private void addHistoryCard(String title, String body, boolean good){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackgroundResource(good?R.drawable.bg_test_solved:R.drawable.bg_card);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12); card.setLayoutParams(lp);
        TextView t=new TextView(this); t.setText(title); t.setTextSize(15); t.setTextColor(good?0xFF166534:0xFF0F172A); t.setTypeface(null, Typeface.BOLD);
        TextView b=new TextView(this); b.setText(body); b.setTextSize(13); b.setTextColor(0xFF475569); b.setPadding(0,6,0,0); b.setLineSpacing(3,1);
        card.addView(t); card.addView(b); layoutHistory.addView(card);
    }

    private void addHistoryCard(int id, String source, int testNo, String unite, int d, int y, int e, String title, String body, boolean good){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(18,18,18,18); card.setBackgroundResource(good?R.drawable.bg_test_solved:R.drawable.bg_card);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12); card.setLayoutParams(lp);
        TextView t=new TextView(this); t.setText(title); t.setTextSize(15); t.setTextColor(good?0xFF166534:0xFF0F172A); t.setTypeface(null, Typeface.BOLD);
        TextView b=new TextView(this); b.setText(body); b.setTextSize(13); b.setTextColor(0xFF475569); b.setPadding(0,6,0,0); b.setLineSpacing(3,1);
        card.addView(t); card.addView(b); card.setOnClickListener(v -> showHistoryActions(id, source, testNo, unite, d, y, e)); layoutHistory.addView(card);
    }

    private void showHistoryActions(int id, String source, int testNo, String unite, int d, int y, int e){
        new AlertDialog.Builder(this)
                .setTitle("Test kaydı")
                .setMessage("Bu eski test kaydı için işlem seç.")
                .setPositiveButton("Güncelle", (dialog, which) -> fillFormForUpdate(id, source, testNo, unite, d, y, e))
                .setNegativeButton("Sil", (dialog, which) -> { dbHelper.deleteTestById(id); renderHistory(); toast("Test kaydı silindi."); })
                .setNeutralButton("Vazgeç", null)
                .show();
    }

    private void fillFormForUpdate(int id, String source, int testNo, String unite, int d, int y, int e){
        etBookName.setText(source == null ? "" : source);
        etTestNo.setText(testNo > 0 ? String.valueOf(testNo) : "");
        etUnite.setText(unite == null ? "Genel" : unite);
        etSoruNo.setText(String.valueOf(d + y + e));
        etCorrect.setText(String.valueOf(d));
        etWrong.setText(String.valueOf(y));
        etEmpty.setText(String.valueOf(e));
        txtInfo.setText("Güncelleme modu: Kaydet dediğinde bu kayıt yenilenir.");
        findViewById(R.id.btnSaveTest).setOnClickListener(v -> updateExistingTest(id));
    }

    private void updateExistingTest(int id){
        try {
            String source=etBookName.getText().toString().trim(); String unite=etUnite.getText().toString().trim();
            int total=Integer.parseInt(etSoruNo.getText().toString().trim()); int d=parse(etCorrect), y=parse(etWrong), b=parse(etEmpty);
            int testNo=etTestNo.getText().toString().trim().isEmpty()?0:Integer.parseInt(etTestNo.getText().toString().trim());
            if(total<=0||total>300||d<0||y<0||b<0||d+y+b!=total){ toast("Toplam ve D/Y/B değerlerini kontrol et."); return; }
            dbHelper.updateTestById(id, source.isEmpty()?"Bağımsız / öğretmen testi":source, testNo, unite.isEmpty()?"Genel":unite, d, y, b);
            txtInfo.setText("Kayıt güncellendi. Yeni test girebilirsin."); clearAfterSave(); renderHistory();
            findViewById(R.id.btnSaveTest).setOnClickListener(v -> saveTestResult());
        } catch(Exception ex){ toast("Sayı alanlarını kontrol et."); }
    }

    private int parse(EditText e){ String s=e.getText().toString().trim(); return s.isEmpty()?0:Integer.parseInt(s); }
    private void toast(String m){ Toast.makeText(this,m,Toast.LENGTH_LONG).show(); }
    @Override public boolean onSupportNavigateUp(){ finish(); return true; }
}
