package com.beykent.akillitestanaliz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private final Context appContext;

    private static final String DATABASE_NAME = "AkilliTestDB";
    private static final int DATABASE_VERSION = 31;

    public static final String TABLE_BOOKS = "books";
    public static final String TABLE_SOLVED_TESTS = "solved_tests";
    public static final String TABLE_WRONG_BOX = "wrong_box";
    public static final String TABLE_EXAM_RESULTS = "exam_results";
    public static final String TABLE_EXAM_LESSONS = "exam_lessons";

    public static final String COL_ID = "id";
    public static final String COL_BOOK_NAME = "book_name";
    public static final String COL_BOOK_SUBJECT = "book_subject";
    public static final String COL_BOOK_EXAM_TYPE = "exam_type";
    public static final String COL_BOOK_TOTAL_TESTS = "total_tests";
    public static final String COL_SOLVED_BOOK_ID = "book_id";
    public static final String COL_TEST_NO = "test_no";
    public static final String COL_CORRECT = "correct";
    public static final String COL_WRONG = "wrong";
    public static final String COL_EMPTY = "empty";
    public static final String COL_SOLVED_UNITE = "unite_adi";
    public static final String COL_SOURCE_NAME = "source_name";
    public static final String COL_SOLVED_EXAM_TYPE = "exam_type";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.appContext = context.getApplicationContext();
    }

    @Override public void onCreate(SQLiteDatabase db) { createAllTables(db); }


    @Override public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        createAllTables(db);
        addColumnIfMissing(db, TABLE_BOOKS, COL_BOOK_EXAM_TYPE, "TEXT DEFAULT 'YKS'");
        addColumnIfMissing(db, TABLE_BOOKS, COL_BOOK_TOTAL_TESTS, "INTEGER DEFAULT 20");
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, COL_SOLVED_UNITE, "TEXT DEFAULT 'Genel'");
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, COL_SOURCE_NAME, "TEXT DEFAULT 'Bağımsız test'");
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, COL_SOLVED_EXAM_TYPE, "TEXT DEFAULT 'TYT'");
        backfillSolvedTestExamTypes(db);
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, "created_at", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "unite", "TEXT DEFAULT ''");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "status", "TEXT DEFAULT 'Çözülmedi'");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "tried_self", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "video_done", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "teacher_asked", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "note", "TEXT DEFAULT ''");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "exam_type", "TEXT DEFAULT 'TYT'");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        createAllTables(db);
        addColumnIfMissing(db, TABLE_BOOKS, COL_BOOK_EXAM_TYPE, "TEXT DEFAULT 'YKS'");
        addColumnIfMissing(db, TABLE_BOOKS, COL_BOOK_TOTAL_TESTS, "INTEGER DEFAULT 20");
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, COL_SOLVED_UNITE, "TEXT DEFAULT 'Genel'");
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, COL_SOURCE_NAME, "TEXT DEFAULT 'Bağımsız test'");
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, COL_SOLVED_EXAM_TYPE, "TEXT DEFAULT 'TYT'");
        backfillSolvedTestExamTypes(db);
        addColumnIfMissing(db, TABLE_SOLVED_TESTS, "created_at", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "unite", "TEXT DEFAULT ''");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "status", "TEXT DEFAULT 'Çözülmedi'");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "tried_self", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "video_done", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "teacher_asked", "INTEGER DEFAULT 0");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "note", "TEXT DEFAULT ''");
        addColumnIfMissing(db, TABLE_WRONG_BOX, "exam_type", "TEXT DEFAULT 'TYT'");
    }

    private void createAllTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_BOOKS + "(" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_BOOK_NAME + " TEXT, " +
                COL_BOOK_SUBJECT + " TEXT, " +
                COL_BOOK_EXAM_TYPE + " TEXT, " +
                COL_BOOK_TOTAL_TESTS + " INTEGER DEFAULT 20)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_SOLVED_TESTS + "(" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SOLVED_BOOK_ID + " INTEGER DEFAULT -1, " +
                COL_TEST_NO + " INTEGER DEFAULT 0, " +
                COL_CORRECT + " INTEGER DEFAULT 0, " +
                COL_WRONG + " INTEGER DEFAULT 0, " +
                COL_EMPTY + " INTEGER DEFAULT 0, " +
                COL_SOLVED_UNITE + " TEXT, " +
                COL_SOURCE_NAME + " TEXT DEFAULT 'Bağımsız test', " +
                COL_SOLVED_EXAM_TYPE + " TEXT DEFAULT 'TYT', " +
                "created_at INTEGER DEFAULT 0)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_WRONG_BOX + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "book_name TEXT, " +
                "unite TEXT, " +
                "soru_no INTEGER DEFAULT 0, " +
                "is_resolved INTEGER DEFAULT 0, " +
                "status TEXT DEFAULT 'Çözülmedi', " +
                "tried_self INTEGER DEFAULT 0, " +
                "video_done INTEGER DEFAULT 0, " +
                "teacher_asked INTEGER DEFAULT 0, " +
                "exam_type TEXT DEFAULT 'TYT', " +
                "note TEXT DEFAULT '')");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_EXAM_RESULTS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "exam_type TEXT, exam_name TEXT, created_at INTEGER, " +
                "turkce_d REAL DEFAULT 0, turkce_y REAL DEFAULT 0, turkce_b REAL DEFAULT 0, turkce_net REAL DEFAULT 0, " +
                "sosyal_d REAL DEFAULT 0, sosyal_y REAL DEFAULT 0, sosyal_b REAL DEFAULT 0, sosyal_net REAL DEFAULT 0, " +
                "mat_d REAL DEFAULT 0, mat_y REAL DEFAULT 0, mat_b REAL DEFAULT 0, mat_net REAL DEFAULT 0, " +
                "fen_d REAL DEFAULT 0, fen_y REAL DEFAULT 0, fen_b REAL DEFAULT 0, fen_net REAL DEFAULT 0, " +
                "toplam_net REAL DEFAULT 0)");

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_EXAM_LESSONS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "exam_type TEXT, exam_name TEXT, created_at INTEGER, " +
                "lesson_name TEXT, lesson_group TEXT, max_question INTEGER DEFAULT 0, " +
                "correct REAL DEFAULT 0, wrong REAL DEFAULT 0, empty REAL DEFAULT 0, net REAL DEFAULT 0)");
    }

    private void addColumnIfMissing(SQLiteDatabase db, String table, String column, String type) {
        try { db.execSQL("ALTER TABLE " + table + " ADD COLUMN " + column + " " + type); } catch (Exception ignored) {}
    }


    private void backfillSolvedTestExamTypes(SQLiteDatabase db) {
        try {
            db.execSQL(
                "UPDATE " + TABLE_SOLVED_TESTS +
                " SET " + COL_SOLVED_EXAM_TYPE + " = COALESCE((" +
                "SELECT " + COL_BOOK_EXAM_TYPE + " FROM " + TABLE_BOOKS +
                " WHERE " + TABLE_BOOKS + "." + COL_ID + " = " + TABLE_SOLVED_TESTS + "." + COL_SOLVED_BOOK_ID +
                "), " + COL_SOLVED_EXAM_TYPE + ")" +
                " WHERE " + COL_SOLVED_BOOK_ID + " > 0"
            );
        } catch (Exception ignored) {}
    }

    public void saveBook(String name, String subject, String examType, int totalTests) {
        SQLiteDatabase db = getWritableDatabase(); ContentValues cv = new ContentValues();
        examType = normalizeExamType(examType);
        cv.put(COL_BOOK_NAME, name); cv.put(COL_BOOK_SUBJECT, subject); cv.put(COL_BOOK_EXAM_TYPE, examType); cv.put(COL_BOOK_TOTAL_TESTS, Math.max(1,totalTests));
        db.insert(TABLE_BOOKS, null, cv);
    }

    public boolean isTestSolved(int bookId, int testNo) {
        if (bookId < 0 || testNo <= 0) return false;
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT 1 FROM " + TABLE_SOLVED_TESTS + " WHERE " + COL_SOLVED_BOOK_ID + "=? AND " + COL_TEST_NO + "=?", new String[]{String.valueOf(bookId), String.valueOf(testNo)});
        boolean exists = c.moveToFirst(); c.close(); return exists;
    }

    public void saveTestResult(int bookId, int testNo, String uniteAdi, int correct, int wrong, int empty) {
        saveAnyTestResult(bookId, testNo, getBookName(bookId), uniteAdi, correct, wrong, empty);
    }

    public void saveAnyTestResult(int bookId, int testNo, String sourceName, String uniteAdi, int correct, int wrong, int empty) {
        SQLiteDatabase db = getWritableDatabase(); ContentValues cv = new ContentValues();
        boolean existing = bookId > 0 && testNo > 0 && isTestSolved(bookId, testNo);
        cv.put(COL_SOLVED_BOOK_ID, bookId); cv.put(COL_TEST_NO, Math.max(0,testNo)); cv.put(COL_CORRECT, correct); cv.put(COL_WRONG, wrong); cv.put(COL_EMPTY, empty);
        cv.put(COL_SOLVED_UNITE, uniteAdi); cv.put(COL_SOURCE_NAME, sourceName == null || sourceName.trim().isEmpty() ? "Bağımsız test" : sourceName.trim()); cv.put(COL_SOLVED_EXAM_TYPE, bookId > 0 ? getBookExamType(bookId) : getActiveExamType()); cv.put("created_at", System.currentTimeMillis());
        if (existing) {
            db.update(TABLE_SOLVED_TESTS, cv, COL_SOLVED_BOOK_ID + "=? AND " + COL_TEST_NO + "=?", new String[]{String.valueOf(bookId), String.valueOf(testNo)});
        } else {
            db.insert(TABLE_SOLVED_TESTS, null, cv);
            if (wrong > 0) insertWrongWithExamType(sourceName, uniteAdi, testNo, "Çözülmedi", "Testten otomatik eklendi: " + wrong + " yanlış", bookId > 0 ? getBookExamType(bookId) : getActiveExamType());
        }
    }

    public void insertWrong(String source, String unite, int soruNo, String status, String note) {
        insertWrongWithExamType(source, unite, soruNo, status, note, getActiveExamType());
    }

    public void insertWrongWithExamType(String source, String unite, int soruNo, String status, String note, String examType) {
        SQLiteDatabase db = getWritableDatabase(); ContentValues wv = new ContentValues();
        wv.put("book_name", source == null || source.trim().isEmpty() ? "Bağımsız test" : source.trim());
        wv.put("unite", unite == null || unite.trim().isEmpty() ? "Genel" : unite.trim());
        wv.put("soru_no", soruNo); wv.put("is_resolved", "Çözüldü".equals(status) ? 1 : 0); wv.put("status", status); wv.put("tried_self",0); wv.put("video_done",0); wv.put("teacher_asked",0); wv.put("exam_type", normalizeExamType(examType)); wv.put("note", note);
        db.insert(TABLE_WRONG_BOX, null, wv);
    }

    public Cursor getWrongByStatus(String status) {
        return getReadableDatabase().rawQuery("SELECT id, book_name, unite, soru_no, status, tried_self, video_done, teacher_asked, note FROM " + TABLE_WRONG_BOX + " WHERE status=? AND " + examWhere("exam_type") + " ORDER BY id DESC", new String[]{status});
    }
    public void updateWrongStatus(int id, String status) { ContentValues cv=new ContentValues(); cv.put("status",status); cv.put("is_resolved","Çözüldü".equals(status)?1:0); getWritableDatabase().update(TABLE_WRONG_BOX,cv,"id=?",new String[]{String.valueOf(id)}); }
    public void updateWrongAction(int id, String field, int value) { if (!field.equals("tried_self") && !field.equals("video_done") && !field.equals("teacher_asked")) return; ContentValues cv=new ContentValues(); cv.put(field,value); getWritableDatabase().update(TABLE_WRONG_BOX,cv,"id=?",new String[]{String.valueOf(id)}); }
    public void updateWrongActionExclusive(int id, String field) { if (!field.equals("tried_self") && !field.equals("video_done") && !field.equals("teacher_asked")) return; ContentValues cv=new ContentValues(); cv.put("tried_self",0); cv.put("video_done",0); cv.put("teacher_asked",0); cv.put(field,1); getWritableDatabase().update(TABLE_WRONG_BOX,cv,"id=?",new String[]{String.valueOf(id)}); }
    public void updateWrongStage(int id, int stage) {
        ContentValues cv = new ContentValues();
        cv.put("tried_self", stage >= 1 ? 1 : 0);
        cv.put("video_done", stage >= 2 ? 1 : 0);
        cv.put("teacher_asked", stage >= 3 ? 1 : 0);
        getWritableDatabase().update(TABLE_WRONG_BOX, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public void setWrongCurrentStep(int id, int step) {
        ContentValues cv = new ContentValues();
        cv.put("tried_self", step == 1 ? 1 : 0);
        cv.put("video_done", step == 2 ? 1 : 0);
        cv.put("teacher_asked", step == 3 ? 1 : 0);
        cv.put("status", "Çözülmedi");
        cv.put("is_resolved", 0);
        getWritableDatabase().update(TABLE_WRONG_BOX, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public void markWrongSolved(int id) {
        ContentValues cv = new ContentValues();
        cv.put("status", "Çözüldü");
        cv.put("is_resolved", 1);
        getWritableDatabase().update(TABLE_WRONG_BOX, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public String getDashboardRecentSummary() {
        StringBuilder sb = new StringBuilder();
        Cursor tests = getRecentTests(2);
        int no = 1;
        if (tests.moveToFirst()) {
            sb.append("Son testler\n");
            do {
                String source = tests.getString(1);
                int testNo = tests.getInt(2);
                String topic = tests.getString(3);
                int d = tests.getInt(4), y = tests.getInt(5), b = tests.getInt(6);
                sb.append(no++).append(") ").append(source == null ? "Test" : source);
                if (testNo > 0) sb.append(" · Test ").append(testNo);
                sb.append(" · ").append(topic == null ? "Genel" : topic)
                  .append(" | D:").append(d).append(" Y:").append(y).append(" B:").append(b).append("\n");
            } while (tests.moveToNext());
        }
        tests.close();

        Cursor exams = getExamHistoryManage(1);
        if (exams.moveToFirst()) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("Son deneme\n")
              .append(exams.getString(1)).append(" · ").append(exams.getString(2))
              .append(" | Net: ").append(String.format(java.util.Locale.US, "%.2f", exams.getFloat(3)));
        }
        exams.close();

        if (sb.length() == 0) return "Henüz son kayıt yok. İlk testini veya denemeni ekle.";
        return sb.toString().trim();
    }


    public String getDailyMotivation() {
        String[] quotes = new String[]{
                "💬 Bugün hedef: az ama net çalış. Bir konu, bir test, bir yanlış kapat.",
                "💬 Net artışı tesadüf değil; kaydet, analiz et, tekrar yap.",
                "💬 Yanlışların moral bozmak için değil, çalışma yönünü göstermek için var.",
                "💬 Bugün 20 dakika düzenli çalışma, yarın panikten daha değerlidir.",
                "💬 En zayıf ders kaçılacak ders değil, en hızlı gelişecek derstir."
        };
        int index = (int) ((System.currentTimeMillis() / 86400000L) % quotes.length);
        return quotes[index];
    }

    public Cursor getAllTests() {
        return getReadableDatabase().rawQuery("SELECT " + COL_ID + ", " + COL_SOURCE_NAME + ", " + COL_TEST_NO + ", " + COL_SOLVED_UNITE + ", " + COL_CORRECT + ", " + COL_WRONG + ", " + COL_EMPTY + ", " + COL_SOLVED_BOOK_ID + " FROM " + TABLE_SOLVED_TESTS + " ORDER BY " + COL_ID + " DESC", null);
    }

    public void saveExamResult(String type, String name, float[] d, float[] y, float[] b) {
        float[] net = new float[4]; float total = 0; for(int i=0;i<4;i++){ net[i]=d[i]-(y[i]/4f); total+=net[i]; }
        SQLiteDatabase db=getWritableDatabase(); ContentValues cv=new ContentValues();
        type = normalizeExamType(type); cv.put("exam_type",type); cv.put("exam_name",name); cv.put("created_at",System.currentTimeMillis());
        String[] p={"turkce","sosyal","mat","fen"}; for(int i=0;i<4;i++){ cv.put(p[i]+"_d",d[i]); cv.put(p[i]+"_y",y[i]); cv.put(p[i]+"_b",b[i]); cv.put(p[i]+"_net",net[i]); }
        cv.put("toplam_net", total); db.insert(TABLE_EXAM_RESULTS,null,cv);
    }

    public void saveExamLessonRows(String type, String name, String[] lessonNames, String[] groups, int[] maxes, float[] d, float[] y, float[] b) {
        long now = System.currentTimeMillis();
        SQLiteDatabase db = getWritableDatabase();
        for (int i = 0; i < lessonNames.length; i++) {
            ContentValues cv = new ContentValues();
            type = normalizeExamType(type); cv.put("exam_type", type); cv.put("exam_name", name); cv.put("created_at", now);
            cv.put("lesson_name", lessonNames[i]); cv.put("lesson_group", groups[i]); cv.put("max_question", maxes[i]);
            cv.put("correct", d[i]); cv.put("wrong", y[i]); cv.put("empty", b[i]); cv.put("net", d[i] - (y[i] / 4f));
            db.insert(TABLE_EXAM_LESSONS, null, cv);
        }
    }

    public Cursor getExamLessonHistory(int limit) {
        return getReadableDatabase().rawQuery("SELECT exam_type, exam_name, lesson_name, correct, wrong, empty, net, created_at, max_question FROM " + TABLE_EXAM_LESSONS + " ORDER BY created_at DESC, id ASC LIMIT " + Math.max(1, limit), null);
    }

    public Cursor getExamLessonStats() {
        return getReadableDatabase().rawQuery("SELECT lesson_name, SUM(correct), SUM(wrong), SUM(empty), SUM(net), COUNT(*) FROM " + TABLE_EXAM_LESSONS + " WHERE " + examWhere("exam_type") + " GROUP BY lesson_name ORDER BY SUM(wrong) DESC, SUM(net) ASC", null);
    }

    public String getWeakestExamLessonName() {
        Cursor c = getReadableDatabase().rawQuery("SELECT lesson_name FROM " + TABLE_EXAM_LESSONS + " WHERE " + examWhere("exam_type") + " GROUP BY lesson_name ORDER BY SUM(wrong) DESC, SUM(net) ASC LIMIT 1", null);
        String r = "Deneme verisi yok"; if (c.moveToFirst()) r = c.getString(0); c.close(); return r;
    }

    public String getStrongestExamLessonName() {
        Cursor c = getReadableDatabase().rawQuery("SELECT lesson_name FROM " + TABLE_EXAM_LESSONS + " WHERE " + examWhere("exam_type") + " GROUP BY lesson_name ORDER BY SUM(net) DESC LIMIT 1", null);
        String r = "Deneme verisi yok"; if (c.moveToFirst()) r = c.getString(0); c.close(); return r;
    }

    public Cursor getExamTrend(int limit) {
        return getReadableDatabase().rawQuery("SELECT exam_type, exam_name, toplam_net FROM " + TABLE_EXAM_RESULTS + " WHERE " + examWhere("exam_type") + " ORDER BY id DESC LIMIT " + Math.max(2, limit), null);
    }

    public int getUnresolvedWrongCount() { return getWrongCountByStatus("Çözülmedi"); }

    public void updateTestById(int id, String sourceName, int testNo, String uniteAdi, int correct, int wrong, int empty) {
        ContentValues cv = new ContentValues();
        cv.put(COL_SOURCE_NAME, sourceName == null || sourceName.trim().isEmpty() ? "Bağımsız test" : sourceName.trim());
        cv.put(COL_TEST_NO, Math.max(0, testNo)); cv.put(COL_SOLVED_UNITE, uniteAdi == null || uniteAdi.trim().isEmpty() ? "Genel" : uniteAdi.trim());
        cv.put(COL_CORRECT, correct); cv.put(COL_WRONG, wrong); cv.put(COL_EMPTY, empty);
        cv.put(COL_SOLVED_EXAM_TYPE, getActiveExamType());
        getWritableDatabase().update(TABLE_SOLVED_TESTS, cv, COL_ID + "=?", new String[]{String.valueOf(id)});
    }

    public void deleteTestById(int id) { getWritableDatabase().delete(TABLE_SOLVED_TESTS, COL_ID + "=?", new String[]{String.valueOf(id)}); }

    public int[] getTestResult(int bookId, int testNo) {
        Cursor c = getReadableDatabase().rawQuery("SELECT " + COL_CORRECT + ", " + COL_WRONG + ", " + COL_EMPTY + " FROM " + TABLE_SOLVED_TESTS + " WHERE " + COL_SOLVED_BOOK_ID + "=? AND " + COL_TEST_NO + "=? LIMIT 1", new String[]{String.valueOf(bookId), String.valueOf(testNo)});
        int[] r = null;
        if (c.moveToFirst()) r = new int[]{c.getInt(0), c.getInt(1), c.getInt(2)};
        c.close();
        return r;
    }

    public void deleteTestResult(int bookId, int testNo) {
        getWritableDatabase().delete(TABLE_SOLVED_TESTS, COL_SOLVED_BOOK_ID + "=? AND " + COL_TEST_NO + "=?", new String[]{String.valueOf(bookId), String.valueOf(testNo)});
    }

    public float getPreviousExamNet(String type) {
        type = normalizeExamType(type); String where = "AYT".equals(type) ? "(exam_type=\'AYT\' OR exam_type=\'YKS\')" : "exam_type=\'" + type.replace("\'", "") + "\'"; Cursor c = getReadableDatabase().rawQuery("SELECT toplam_net FROM " + TABLE_EXAM_RESULTS + " WHERE " + where + " ORDER BY id DESC LIMIT 1 OFFSET 1", null);
        float n = -1;
        if (c.moveToFirst()) n = c.getFloat(0);
        c.close();
        return n;
    }

    public String getLatestExamType() {
        Cursor c = getReadableDatabase().rawQuery("SELECT exam_type FROM " + TABLE_EXAM_RESULTS + " ORDER BY id DESC LIMIT 1", null);
        String t = "TYT";
        if (c.moveToFirst()) t = c.getString(0);
        c.close();
        return normalizeExamType(t);
    }

    // Koçluk ekranlarında TYT, AYT/YKS, LGS ve KPSS verileri ayrı değerlendirilir.
    // Böylece TYT kitabı ile AYT/YKS kitabı aynı başarı hesabına karışmaz.
    public String getActiveExamType() {
        // Aktif sınav türü kullanıcının Dashboard üzerinde seçtiği değerden gelir.
        // Bu sayede en son eklenen TYT/AYT denemesi paneli otomatik bozmaz.
        return normalizeExamType(TimePrefs.getActiveExamType(appContext));
    }

    public void setActiveExamType(String type) {
        TimePrefs.setActiveExamType(appContext, normalizeExamType(type));
    }

    private String normalizeExamType(String raw) {
        if (raw == null) return "TYT";
        String t = raw.trim().toUpperCase(new java.util.Locale("tr", "TR"));
        if (t.contains("YKS") || t.contains("AYT")) return "AYT";
        if (t.contains("LGS")) return "LGS";
        if (t.contains("KPSS")) return "KPSS";
        if (t.contains("TYT")) return "TYT";
        return t.length() == 0 ? "TYT" : t;
    }

    private String examWhere(String columnName) {
        String active = getActiveExamType();
        if ("AYT".equals(active)) return "(" + columnName + "='AYT' OR " + columnName + "='YKS')";
        return columnName + "='" + active.replace("'", "") + "'";
    }


    public long saveCompleteExamResult(String type, String name, String[] lessonNames, String[] groups, int[] maxes, float[] d, float[] y, float[] b) {
        long now = System.currentTimeMillis();
        float[] groupedD = new float[4], groupedY = new float[4], groupedB = new float[4], groupedNet = new float[4];
        for (int i = 0; i < lessonNames.length; i++) {
            int idx = groups[i].equals("turkce") ? 0 : groups[i].equals("sosyal") ? 1 : groups[i].equals("mat") ? 2 : 3;
            groupedD[idx] += d[i]; groupedY[idx] += y[i]; groupedB[idx] += b[i];
            groupedNet[idx] += d[i] - (y[i] / 4f);
        }
        float total = groupedNet[0] + groupedNet[1] + groupedNet[2] + groupedNet[3];
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        type = normalizeExamType(type); cv.put("exam_type", type); cv.put("exam_name", name); cv.put("created_at", now);
        String[] pref = {"turkce", "sosyal", "mat", "fen"};
        for (int i = 0; i < 4; i++) {
            cv.put(pref[i] + "_d", groupedD[i]); cv.put(pref[i] + "_y", groupedY[i]); cv.put(pref[i] + "_b", groupedB[i]); cv.put(pref[i] + "_net", groupedNet[i]);
        }
        cv.put("toplam_net", total);
        long examId = db.insert(TABLE_EXAM_RESULTS, null, cv);
        for (int i = 0; i < lessonNames.length; i++) {
            ContentValues lv = new ContentValues();
            lv.put("exam_type", type); lv.put("exam_name", name); lv.put("created_at", now);
            lv.put("lesson_name", lessonNames[i]); lv.put("lesson_group", groups[i]); lv.put("max_question", maxes[i]);
            lv.put("correct", d[i]); lv.put("wrong", y[i]); lv.put("empty", b[i]); lv.put("net", d[i] - (y[i] / 4f));
            db.insert(TABLE_EXAM_LESSONS, null, lv);
        }
        return examId;
    }

    public Cursor getExamHistoryManage(int limit) {
        return getReadableDatabase().rawQuery("SELECT id, exam_type, exam_name, toplam_net, turkce_net, sosyal_net, mat_net, fen_net, created_at FROM " + TABLE_EXAM_RESULTS + " WHERE " + examWhere("exam_type") + " ORDER BY id DESC LIMIT " + Math.max(1, limit), null);
    }

    public void deleteExamById(int id) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT exam_type, exam_name, created_at FROM " + TABLE_EXAM_RESULTS + " WHERE id=?", new String[]{String.valueOf(id)});
        if (c.moveToFirst()) {
            String type = c.getString(0); String name = c.getString(1); String created = String.valueOf(c.getLong(2));
            db.delete(TABLE_EXAM_LESSONS, "exam_type=? AND exam_name=? AND created_at=?", new String[]{type, name, created});
            // Eski sürümlerde lesson timestamp'i farklı kaydedilmiş olabilir; isim+tür ile kalanları da temizle.
            db.delete(TABLE_EXAM_LESSONS, "exam_type=? AND exam_name=?", new String[]{type, name});
        }
        c.close();
        db.delete(TABLE_EXAM_RESULTS, "id=?", new String[]{String.valueOf(id)});
    }

    public Cursor getExamLessonsByExamId(int examId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor meta = db.rawQuery("SELECT exam_type, exam_name, created_at FROM " + TABLE_EXAM_RESULTS + " WHERE id=?", new String[]{String.valueOf(examId)});
        if (meta.moveToFirst()) {
            String type = meta.getString(0);
            String name = meta.getString(1);
            String created = String.valueOf(meta.getLong(2));
            meta.close();
            return db.rawQuery("SELECT lesson_name, lesson_group, max_question, correct, wrong, empty FROM " + TABLE_EXAM_LESSONS + " WHERE exam_type=? AND exam_name=? AND created_at=? ORDER BY id ASC", new String[]{type, name, created});
        }
        meta.close();
        return db.rawQuery("SELECT lesson_name, lesson_group, max_question, correct, wrong, empty FROM " + TABLE_EXAM_LESSONS + " WHERE 1=0", null);
    }

    public Cursor getExamHistoryFull(int limit) {
        return getReadableDatabase().rawQuery("SELECT id, exam_type, exam_name, toplam_net, turkce_net, sosyal_net, mat_net, fen_net, created_at FROM " + TABLE_EXAM_RESULTS + " WHERE " + examWhere("exam_type") + " ORDER BY id DESC LIMIT " + Math.max(1, limit), null);
    }

    public Cursor getWorstExamLessons(int limit) {
        return getReadableDatabase().rawQuery("SELECT lesson_name, SUM(correct) d, SUM(wrong) y, SUM(empty) b, SUM(net) n, COUNT(*) c FROM " + TABLE_EXAM_LESSONS + " WHERE " + examWhere("exam_type") + " GROUP BY lesson_name ORDER BY SUM(wrong) DESC, SUM(net) ASC LIMIT " + Math.max(1, limit), null);
    }


    public Cursor getExamHistory() { return getReadableDatabase().rawQuery("SELECT exam_type, exam_name, toplam_net, turkce_net, sosyal_net, mat_net, fen_net, created_at FROM " + TABLE_EXAM_RESULTS + " WHERE " + examWhere("exam_type") + " ORDER BY id DESC LIMIT 20", null); }
    public float getLastExamNet() { Cursor c=getReadableDatabase().rawQuery("SELECT toplam_net FROM "+TABLE_EXAM_RESULTS+" WHERE "+examWhere("exam_type")+" ORDER BY id DESC LIMIT 1", null); float n=0; if(c.moveToFirst()) n=c.getFloat(0); c.close(); return n; }
    public int getExamCount() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+TABLE_EXAM_RESULTS+" WHERE "+examWhere("exam_type"), null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }

    public int getBookTotalTests(int bookId) { Cursor c=getReadableDatabase().rawQuery("SELECT "+COL_BOOK_TOTAL_TESTS+" FROM "+TABLE_BOOKS+" WHERE "+COL_ID+"=?",new String[]{String.valueOf(bookId)}); int t=20; if(c.moveToFirst()) t=c.getInt(0); c.close(); return Math.max(1,t); }

    public String getBookName(int bookId) { if(bookId<0) return "Bağımsız test"; Cursor c=getReadableDatabase().rawQuery("SELECT "+COL_BOOK_NAME+" FROM "+TABLE_BOOKS+" WHERE "+COL_ID+"=?",new String[]{String.valueOf(bookId)}); String name="Bilinmeyen kaynak"; if(c.moveToFirst()) name=c.getString(0); c.close(); return name; }

    public String getBookExamType(int bookId) { if(bookId<0) return getActiveExamType(); Cursor c=getReadableDatabase().rawQuery("SELECT "+COL_BOOK_EXAM_TYPE+" FROM "+TABLE_BOOKS+" WHERE "+COL_ID+"=?",new String[]{String.valueOf(bookId)}); String type=getActiveExamType(); if(c.moveToFirst()) type=c.getString(0); c.close(); return normalizeExamType(type); }


    public int getBookSolvedTestCount(int bookId) { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT "+COL_TEST_NO+") FROM "+TABLE_SOLVED_TESTS+" WHERE "+COL_SOLVED_BOOK_ID+"=? AND "+COL_TEST_NO+">0",new String[]{String.valueOf(bookId)}); int solved=0; if(c.moveToFirst()) solved=c.getInt(0); c.close(); return solved; }

    public int getBookProgress(int bookId) {
        Cursor bc=getReadableDatabase().rawQuery("SELECT "+COL_BOOK_TOTAL_TESTS+" FROM "+TABLE_BOOKS+" WHERE "+COL_ID+"=?",new String[]{String.valueOf(bookId)}); int total=0; if(bc.moveToFirst()) total=bc.getInt(0); bc.close(); if(total<=0) return 0;
        Cursor sc=getReadableDatabase().rawQuery("SELECT COUNT(DISTINCT "+COL_TEST_NO+") FROM "+TABLE_SOLVED_TESTS+" WHERE "+COL_SOLVED_BOOK_ID+"=? AND "+COL_TEST_NO+">0",new String[]{String.valueOf(bookId)}); int solved=0; if(sc.moveToFirst()) solved=sc.getInt(0); sc.close(); if (solved <= 0) return 0; return Math.min(100, Math.max(1, (int)Math.ceil(solved*100.0/total)));
    }

    public int getCountByStatus(String column) { Cursor c=getReadableDatabase().rawQuery("SELECT IFNULL(SUM(st."+column+"),0) FROM "+TABLE_SOLVED_TESTS+" st WHERE "+examWhere("st."+COL_SOLVED_EXAM_TYPE),null); int t=0; if(c.moveToFirst()) t=c.getInt(0); c.close(); return t; }
    public int getOverallSuccessPercent() { int d=getCountByStatus(COL_CORRECT), y=getCountByStatus(COL_WRONG), b=getCountByStatus(COL_EMPTY); int t=d+y+b; return t==0?0:(int)((d*100f)/t); }

    public Cursor getSubjectsByExamType(String examType) { String type=normalizeExamType(examType); if("AYT".equals(type)) return getReadableDatabase().rawQuery("SELECT DISTINCT "+COL_BOOK_SUBJECT+" FROM "+TABLE_BOOKS+" WHERE "+COL_BOOK_EXAM_TYPE+" IN ('AYT','YKS') ORDER BY "+COL_BOOK_SUBJECT,null); return getReadableDatabase().rawQuery("SELECT DISTINCT "+COL_BOOK_SUBJECT+" FROM "+TABLE_BOOKS+" WHERE "+COL_BOOK_EXAM_TYPE+"=? ORDER BY "+COL_BOOK_SUBJECT,new String[]{type}); }
    public Cursor getUniteOzetiByDers(String dersAdi) { return getReadableDatabase().rawQuery("SELECT st."+COL_SOLVED_UNITE+", IFNULL(SUM(st."+COL_CORRECT+"),0), IFNULL(SUM(st."+COL_WRONG+"),0), IFNULL(SUM(st."+COL_EMPTY+"),0), COUNT(*) FROM "+TABLE_SOLVED_TESTS+" st JOIN "+TABLE_BOOKS+" b ON st."+COL_SOLVED_BOOK_ID+"=b."+COL_ID+" WHERE b."+COL_BOOK_SUBJECT+"=? AND "+examWhere("b."+COL_BOOK_EXAM_TYPE)+" GROUP BY st."+COL_SOLVED_UNITE+" ORDER BY SUM(st."+COL_WRONG+") DESC",new String[]{dersAdi}); }
    public int[] getDersGenelOzet(String dersAdi) { Cursor c=getReadableDatabase().rawQuery("SELECT IFNULL(SUM(st."+COL_CORRECT+"),0), IFNULL(SUM(st."+COL_WRONG+"),0), IFNULL(SUM(st."+COL_EMPTY+"),0) FROM "+TABLE_SOLVED_TESTS+" st JOIN "+TABLE_BOOKS+" b ON st."+COL_SOLVED_BOOK_ID+"=b."+COL_ID+" WHERE b."+COL_BOOK_SUBJECT+"=? AND "+examWhere("b."+COL_BOOK_EXAM_TYPE),new String[]{dersAdi}); int[] r={0,0,0}; if(c.moveToFirst()){r[0]=c.getInt(0);r[1]=c.getInt(1);r[2]=c.getInt(2);} c.close(); return r; }
    public String getKocMesaji(String dersAdi) { int[] o=getDersGenelOzet(dersAdi); int t=o[0]+o[1]+o[2]; if(t==0) return dersAdi+" için henüz veri yok. Önce test sonucu ekle."; int bas=(int)(o[0]*100f/t); return dersAdi+" başarı: %"+bas+". Yanlış sayısı "+o[1]+". En düşük konulara tekrar + video + hoca sorusu planı ekle."; }
    public String getGenelKocMesaji() { int d=getCountByStatus(COL_CORRECT), y=getCountByStatus(COL_WRONG), b=getCountByStatus(COL_EMPTY); int t=d+y+b; String active=getActiveExamType(); if(t==0 && getExamCount()==0) return active+" için henüz veri yok. Bu sınav türüne ait kitap testi veya deneme ekle."; String msg="Aktif koçluk alanı: "+active+". Toplam "+t+" test sorusu, "+getExamCount()+" deneme var. "; if(y>d/2) msg += "Yanlışların yüksek; Yanlış Kutusu'nda Çözülmedi listesini bitir."; else msg += "Tempo iyi; deneme net trendini takip et."; return msg; }

    public Cursor getRecentTests(int limit) {
        return getReadableDatabase().rawQuery("SELECT st." + COL_ID + ", st." + COL_SOURCE_NAME + ", st." + COL_TEST_NO + ", st." + COL_SOLVED_UNITE + ", st." + COL_CORRECT + ", st." + COL_WRONG + ", st." + COL_EMPTY + ", st." + COL_SOLVED_BOOK_ID + " FROM " + TABLE_SOLVED_TESTS + " st WHERE " + examWhere("st." + COL_SOLVED_EXAM_TYPE) + " ORDER BY st." + COL_ID + " DESC LIMIT " + Math.max(1, limit), null);
    }

    public int getSolvedTestCount() { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+TABLE_SOLVED_TESTS+" st WHERE "+examWhere("st."+COL_SOLVED_EXAM_TYPE),null); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }
    public int getWrongCountByStatus(String status) { Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+TABLE_WRONG_BOX+" WHERE status=? AND "+examWhere("exam_type"),new String[]{status}); int n=0; if(c.moveToFirst()) n=c.getInt(0); c.close(); return n; }

    public String getWeakestSubjectName() {
        String strong = getStrongestSubjectName();
        String weak = getSubjectRankName(false, strong);
        if ("Veri yok".equals(weak) && !"Veri yok".equals(strong)) return "Karşılaştırma için ikinci ders yok";
        return weak;
    }

    public String getStrongestSubjectName() {
        return getSubjectRankName(true, null);
    }

    public String getPriorityTopicName() {
        Cursor c = getTopicPerformance(1);
        String r = "Veri yok";
        if (c.moveToFirst() && c.getString(0) != null && c.getString(0).trim().length() > 0) {
            r = c.getString(0).trim();
        }
        c.close();
        return r;
    }

    private String getSubjectRankName(boolean strongest, String excludeSubject) {
        java.util.HashMap<String, float[]> map = new java.util.HashMap<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor tests = db.rawQuery("SELECT b."+COL_BOOK_SUBJECT+", IFNULL(SUM(st."+COL_CORRECT+"),0), IFNULL(SUM(st."+COL_WRONG+"),0), IFNULL(SUM(st."+COL_EMPTY+"),0) " +
                "FROM "+TABLE_SOLVED_TESTS+" st JOIN "+TABLE_BOOKS+" b ON st."+COL_SOLVED_BOOK_ID+"=b."+COL_ID+" WHERE "+examWhere("b."+COL_BOOK_EXAM_TYPE)+" " +
                "GROUP BY b."+COL_BOOK_SUBJECT, null);
        while (tests.moveToNext()) {
            addSubjectAgg(map, tests.getString(0), tests.getFloat(1), tests.getFloat(2), tests.getFloat(3));
        }
        tests.close();

        Cursor exams = db.rawQuery("SELECT lesson_name, IFNULL(SUM(correct),0), IFNULL(SUM(wrong),0), IFNULL(SUM(empty),0) " +
                "FROM "+TABLE_EXAM_LESSONS+" WHERE "+examWhere("exam_type")+" GROUP BY lesson_name", null);
        while (exams.moveToNext()) {
            addSubjectAgg(map, exams.getString(0), exams.getFloat(1), exams.getFloat(2), exams.getFloat(3));
        }
        exams.close();

        String bestName = "Veri yok";
        float bestScore = strongest ? -1f : 999999f;
        float bestWrong = -1f;
        for (String name : map.keySet()) {
            if (excludeSubject != null && normalizeSubjectName(excludeSubject) != null && name.equals(normalizeSubjectName(excludeSubject))) continue;
            float[] a = map.get(name);
            float total = a[0] + a[1] + a[2];
            if (total <= 0) continue;
            float score = a[0] / total;
            boolean take;
            if (strongest) {
                take = score > bestScore || (score == bestScore && a[1] < bestWrong);
            } else {
                take = score < bestScore || (score == bestScore && a[1] > bestWrong);
            }
            if (take) {
                bestScore = score;
                bestWrong = a[1];
                bestName = name;
            }
        }
        return bestName;
    }

    private void addSubjectAgg(java.util.HashMap<String, float[]> map, String rawName, float correct, float wrong, float empty) {
        String subject = normalizeSubjectName(rawName);
        if (subject == null) return;
        float[] a = map.get(subject);
        if (a == null) {
            a = new float[]{0f,0f,0f};
            map.put(subject, a);
        }
        a[0] += correct;
        a[1] += wrong;
        a[2] += empty;
    }

    private String normalizeSubjectName(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.length() == 0) return null;
        String l = s.toLowerCase(new java.util.Locale("tr", "TR"));
        if (l.contains("türk") || l.equals("turkce")) return "Türkçe";
        if (l.contains("mat")) return "Matematik";
        if (l.contains("geometri")) return "Geometri";
        if (l.contains("tarih")) return "Tarih";
        if (l.contains("coğraf") || l.contains("cograf")) return "Coğrafya";
        if (l.contains("felsefe")) return "Felsefe";
        if (l.equals("din") || l.contains("din kült") || l.contains("din kult")) return "Din Kültürü";
        if (l.contains("fizik")) return "Fizik";
        if (l.contains("kimya")) return "Kimya";
        if (l.contains("biyoloji")) return "Biyoloji";
        if (l.equals("fen") || l.contains("fen bilim")) return "Fen";
        if (l.equals("sosyal") || l.contains("sosyal bilgiler")) return "Sosyal";
        if (l.contains("edebiyat")) return "Edebiyat";
        if (l.contains("paragraf")) return "Türkçe";
        return null;
    }


    public Cursor getTopicPerformance(int limit) {
        return getReadableDatabase().rawQuery("SELECT IFNULL(st."+COL_SOLVED_UNITE+", 'Genel') konu, IFNULL(SUM(st."+COL_CORRECT+"),0) d, IFNULL(SUM(st."+COL_WRONG+"),0) y, IFNULL(SUM(st."+COL_EMPTY+"),0) b, COUNT(*) adet FROM "+TABLE_SOLVED_TESTS+" st JOIN "+TABLE_BOOKS+" b ON st."+COL_SOLVED_BOOK_ID+"=b."+COL_ID+" WHERE "+examWhere("b."+COL_BOOK_EXAM_TYPE)+" GROUP BY IFNULL(st."+COL_SOLVED_UNITE+", 'Genel') ORDER BY SUM(st."+COL_WRONG+") DESC, SUM(st."+COL_CORRECT+") ASC LIMIT " + Math.max(1, limit), null);
    }

    public int getTestsThisWeek() {
        long now = System.currentTimeMillis();
        long weekAgo = now - 7L * 24L * 60L * 60L * 1000L;
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+TABLE_SOLVED_TESTS+" WHERE created_at>=?", new String[]{String.valueOf(weekAgo)});
        int n = 0; if (c.moveToFirst()) n = c.getInt(0); c.close(); return n;
    }

    public int getWrongOpenedThisWeek() {
        return getWrongCountByStatus("Çözülmedi") + getWrongCountByStatus("Tekrar edilecek");
    }

    public String getDashboardDailyPlan() {
        String weak = getWeakestSubjectName();
        String strong = getStrongestSubjectName();
        int unresolved = getWrongCountByStatus("Çözülmedi");
        int repeat = getWrongCountByStatus("Tekrar edilecek");
        int exams = getExamCount();
        if (getSolvedTestCount() == 0 && exams == 0) return "Bugünkü hedef: 1 test veya 1 deneme ekleyip ilk analiz verisini oluştur.";
        StringBuilder sb = new StringBuilder();
        if (!"Veri yok".equals(weak) && !weak.startsWith("Karşılaştırma")) sb.append("Önce ").append(weak).append(" için 20 dk konu tekrar + 1 mini test. ");
        if (!"Veri yok".equals(strong) && !strong.equals(weak)) sb.append(strong).append(" güçlü; sadece kısa hız tekrarı yeter. ");
        if (unresolved > 0) sb.append("Çözülmedi listesinden ").append(Math.min(5, unresolved)).append(" soru kapat. ");
        if (repeat > 0) sb.append("Tekrar listesinden ").append(Math.min(3, repeat)).append(" soru kontrol et. ");
        if (exams == 0) sb.append("Bu hafta en az 1 deneme gir."); else sb.append("Son deneme trendine göre zayıf dersten +2 net hedefle.");
        return sb.toString().trim();
    }

    public String getDynamicWeeklyActionPlan() {
        String weak = getWeakestSubjectName();
        String strong = getStrongestSubjectName();
        int unresolved = getWrongCountByStatus("Çözülmedi");
        int repeat = getWrongCountByStatus("Tekrar edilecek");
        int solved = getWrongCountByStatus("Çözüldü");
        StringBuilder sb = new StringBuilder();
        sb.append("1) Ana odak: ").append(("Veri yok".equals(weak) || weak.startsWith("Karşılaştırma")) ? "farklı derslerden veri oluştur" : weak + " dersi").append("\n");
        if (!"Veri yok".equals(weak) && !weak.startsWith("Karşılaştırma")) sb.append("   Plan: 3 gün boyunca 20 dk konu tekrar + 1 mini test + yanlış kutusu kontrolü.\n");
        if (!"Veri yok".equals(strong) && !strong.equals(weak)) sb.append("2) Koruma dersi: ").append(strong).append(". Haftada 1 süreli karma test yeterli.\n");
        else sb.append("2) Güçlü ders ayrışmadı; farklı derslerden veri ekle.\n");
        sb.append("3) Yanlış kutusu: çözülmedi ").append(unresolved).append(", tekrar ").append(repeat).append(", çözüldü ").append(solved).append(".\n");
        if (unresolved > 0) sb.append("   Günlük hedef: çözülmedi listesinden ").append(Math.min(5, unresolved)).append(" soru kapat.\n");
        if (repeat > 0) sb.append("   Tekrar hedefi: tekrar listesinden ").append(Math.min(3, repeat)).append(" soruyu yeniden çöz.\n");
        sb.append("4) Deneme hedefi: zayıf dersten +2 net, toplamda +3 net artış.");
        return sb.toString();
    }

    public String getSubjectStrategy(String subject, int success, int wrong, int empty) {
        String s = subject == null ? "Bu ders" : subject;
        if (success >= 85 && wrong <= 2) return s + ": seviye iyi. Artık kolay tekrar değil, süreli ve karma zor test çöz. Haftada 1 deneme ile hızı koru.";
        if (wrong >= empty && wrong >= 5) return s + ": yanlış sayısı riskli. Önce yanlış defteri çıkar, sonra konu videosu + 10 benzer soru + hocaya sor planı uygula.";
        if (empty > wrong) return s + ": boş sayısı yüksek. Konu eksiği var; 20 dk temel tekrar, ardından düşük süre baskısıyla mini test çöz.";
        if (success >= 60) return s + ": orta seviye. Her gün 1 konu tekrarı + 1 test + yanlış kutusu kapatma yeterli olur.";
        return s + ": temel zayıf. Önce konu özeti oku, örnek çözüm izle, sonra kolay testten başlayıp kademeli zorlaştır.";
    }


    public String getWrongProcessSummary() {
        int waiting = scalar("SELECT COUNT(*) FROM "+TABLE_WRONG_BOX+" WHERE status!='Çözüldü' AND tried_self=0 AND video_done=0 AND teacher_asked=0");
        int self = scalar("SELECT COUNT(*) FROM "+TABLE_WRONG_BOX+" WHERE status!='Çözüldü' AND tried_self=1 AND video_done=0 AND teacher_asked=0");
        int video = scalar("SELECT COUNT(*) FROM "+TABLE_WRONG_BOX+" WHERE status!='Çözüldü' AND video_done=1 AND teacher_asked=0");
        int teacher = scalar("SELECT COUNT(*) FROM "+TABLE_WRONG_BOX+" WHERE status!='Çözüldü' AND teacher_asked=1");
        return "Bekleyen " + waiting + " | Kendim " + self + " | Video " + video + " | Hoca " + teacher;
    }

    public String buildDetailedCoachReport() {
        int d = getCountByStatus(COL_CORRECT), y = getCountByStatus(COL_WRONG), b = getCountByStatus(COL_EMPTY);
        int total = d + y + b;
        int bas = total == 0 ? 0 : Math.round(d * 100f / total);
        StringBuilder sb = new StringBuilder();
        sb.append("GENEL PERFORMANS\n");
        sb.append("Toplam soru: ").append(total).append(" | Doğru: ").append(d).append(" | Yanlış: ").append(y).append(" | Boş: ").append(b).append("\n");
        sb.append("Genel başarı: %").append(bas).append("\n");
        sb.append("Çözülen test: ").append(getSolvedTestCount()).append(" | Deneme sayısı: ").append(getExamCount()).append("\n\n");

        sb.append("KOÇLUK ÖNCELİĞİ\n");
        sb.append("En güçlü ders: ").append(getStrongestSubjectName()).append("\n");
        sb.append("Öncelikli ders: ").append(getWeakestSubjectName()).append("\n");
        sb.append("Öncelikli konu/çalışma alanı: ").append(getPriorityTopicName()).append("\n");
        sb.append("Yanlış kutusu: Çözülmedi ").append(getWrongCountByStatus("Çözülmedi"))
                .append(" | Tekrar ").append(getWrongCountByStatus("Tekrar edilecek"))
                .append(" | Çözüldü ").append(getWrongCountByStatus("Çözüldü")).append("\n");
        sb.append("Süreç aşamaları: ").append(getWrongProcessSummary()).append("\n");
        sb.append("Haftalık aksiyon planı:\n").append(getDynamicWeeklyActionPlan()).append("\n\n");

        sb.append("DERS BAZLI ÇALIŞMA STRATEJİSİ\n");
        Cursor c = getReadableDatabase().rawQuery("SELECT b."+COL_BOOK_SUBJECT+", IFNULL(SUM(st."+COL_CORRECT+"),0), IFNULL(SUM(st."+COL_WRONG+"),0), IFNULL(SUM(st."+COL_EMPTY+"),0), COUNT(*) FROM "+TABLE_SOLVED_TESTS+" st JOIN "+TABLE_BOOKS+" b ON st."+COL_SOLVED_BOOK_ID+"=b."+COL_ID+" WHERE "+examWhere("b."+COL_BOOK_EXAM_TYPE)+" GROUP BY b."+COL_BOOK_SUBJECT+" ORDER BY SUM(st."+COL_WRONG+") DESC, SUM(st."+COL_CORRECT+") ASC LIMIT 8", null);
        if (!c.moveToFirst()) {
            sb.append("Henüz ders bazlı test verisi yok. Test eklerken kaynak ve ders/konu alanlarını doldur.\n");
        } else {
            do {
                String subject = normalizeSubjectName(c.getString(0));
                if (subject == null) continue;
                int cd = c.getInt(1), cy = c.getInt(2), cb = c.getInt(3);
                int ct = cd + cy + cb;
                int suc = ct == 0 ? 0 : Math.round(cd * 100f / ct);
                sb.append("• ").append(subject).append(" → Başarı %").append(suc).append(" | Yanlış ").append(cy).append(" | Boş ").append(cb).append("\n");
                sb.append("  Strateji: ").append(getSubjectStrategy(subject, suc, cy, cb)).append("\n");
            } while (c.moveToNext());
        }
        c.close();

        sb.append("\nDENEME ANALİZİ\n");
        Cursor e = getExamHistoryFull(5);
        if (!e.moveToFirst()) {
            sb.append("Henüz deneme yok. Net trendi için düzenli deneme ekle.\n");
        } else {
            do {
                sb.append("• ").append(e.getString(1)).append(" - ").append(e.getString(2) == null ? "Deneme" : e.getString(2))
                        .append(" | Toplam net: ").append(String.format(java.util.Locale.US, "%.2f", e.getFloat(3)))
                        .append(" | Türkçe: ").append(String.format(java.util.Locale.US, "%.2f", e.getFloat(4)))
                        .append(" | Sosyal: ").append(String.format(java.util.Locale.US, "%.2f", e.getFloat(5)))
                        .append(" | Mat: ").append(String.format(java.util.Locale.US, "%.2f", e.getFloat(6)))
                        .append(" | Fen: ").append(String.format(java.util.Locale.US, "%.2f", e.getFloat(7))).append("\n");
            } while (e.moveToNext());
        }
        e.close();

        sb.append("\nKONU BAZLI RİSKLER\n");
        Cursor t = getTopicPerformance(8);
        if (!t.moveToFirst()) {
            sb.append("Konu verisi yok. Testlerde konu alanını doldur.\n");
        } else {
            do {
                String konu = t.getString(0) == null ? "Genel" : t.getString(0);
                int td = t.getInt(1), ty = t.getInt(2), tb = t.getInt(3);
                int tt = td + ty + tb;
                int suc = tt == 0 ? 0 : Math.round(td * 100f / tt);
                sb.append("• ").append(konu).append(" → %").append(suc).append(" başarı | Yanlış: ").append(ty).append(" | Öneri: ").append(topicAdvice(suc, ty, tb)).append("\n");
            } while (t.moveToNext());
        }
        t.close();
        return sb.toString();
    }

    public String buildExportSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("Akıllı Test Analiz Raporu\n");
        sb.append("Rapor türü: Detaylı performans ve koçluk raporu\n");
        sb.append("Not: Tahmini sonuçlar resmi değildir; koçluk ve takip amacıyla kullanılır.\n\n");
        sb.append(buildDetailedCoachReport());
        return sb.toString();
    }

    public String buildExportCsv() {
        StringBuilder sb = new StringBuilder();
        sb.append("kategori,baslik,dogru,yanlis,bos,net_basari,onerilen_strateji\n");
        int d=getCountByStatus(COL_CORRECT), y=getCountByStatus(COL_WRONG), b=getCountByStatus(COL_EMPTY);
        int total=d+y+b; int bas=total==0?0:Math.round(d*100f/total);
        sb.append("genel,Genel Performans,").append(d).append(',').append(y).append(',').append(b).append(',').append(bas).append(",").append(cleanCsv(getDashboardDailyPlan())).append("\n");

        Cursor subj = getReadableDatabase().rawQuery("SELECT b."+COL_BOOK_SUBJECT+", IFNULL(SUM(st."+COL_CORRECT+"),0), IFNULL(SUM(st."+COL_WRONG+"),0), IFNULL(SUM(st."+COL_EMPTY+"),0) FROM "+TABLE_SOLVED_TESTS+" st JOIN "+TABLE_BOOKS+" b ON st."+COL_SOLVED_BOOK_ID+"=b."+COL_ID+" WHERE "+examWhere("b."+COL_BOOK_EXAM_TYPE)+" GROUP BY b."+COL_BOOK_SUBJECT+" ORDER BY SUM(st."+COL_WRONG+") DESC", null);
        while(subj.moveToNext()) {
            String subject = normalizeSubjectName(subj.getString(0)); if (subject == null) continue;
            int sd=subj.getInt(1), sy=subj.getInt(2), sbos=subj.getInt(3); int st=sd+sy+sbos; int ss=st==0?0:Math.round(sd*100f/st);
            sb.append("ders,").append(cleanCsv(subject)).append(',').append(sd).append(',').append(sy).append(',').append(sbos).append(',').append(ss).append(',').append(cleanCsv(getSubjectStrategy(subject, ss, sy, sbos))).append("\n");
        }
        subj.close();

        Cursor c = getTopicPerformance(50);
        while(c.moveToNext()) {
            String konu = c.getString(0)==null?"Genel":c.getString(0);
            int td=c.getInt(1), ty=c.getInt(2), tb=c.getInt(3); int tt=td+ty+tb; int ts=tt==0?0:Math.round(td*100f/tt);
            sb.append("konu,").append(cleanCsv(konu)).append(',').append(td).append(',').append(ty).append(',').append(tb).append(',').append(ts).append(',').append(cleanCsv(topicAdvice(ts,ty,tb))).append("\n");
        }
        c.close();

        Cursor e = getExamHistoryFull(50);
        while(e.moveToNext()) {
            sb.append("deneme,").append(cleanCsv(e.getString(1)+" "+(e.getString(2)==null?"Deneme":e.getString(2)))).append(",,,,").append(String.format(java.util.Locale.US,"%.2f",e.getFloat(3))).append(",").append(cleanCsv("Net trendini ve zayıf dersleri analiz ekranından takip et.")).append("\n");
        }
        e.close();
        return sb.toString();
    }

    private int scalar(String sql) {
        Cursor c = getReadableDatabase().rawQuery(sql, null);
        int v = 0;
        if (c.moveToFirst()) v = c.getInt(0);
        c.close();
        return v;
    }

    private String topicAdvice(int success, int wrong, int empty) {
        if (wrong >= 10) {
            return "Öncelik yüksek: önce konu özeti çıkar, ardından 2 kolay + 2 orta test çöz ve yanlışlarını aynı gün kapat.";
        }
        if (wrong >= 5) {
            return "Orta risk: 20 dakika konu tekrarı yap, sonra yanlış türlerini ayırıp kısa tekrar testi çöz.";
        }
        if (empty >= 10) {
            return "Tempo eksiği: süre tutarak pratik yap, boş bıraktığın soru tiplerini işaretle.";
        }
        if (success >= 90) {
            return "Güçlü alan: seviyeyi koru, haftada 1 karma tekrar yeterli.";
        }
        if (success >= 70) {
            return "İyi ama kırılgan: zor sorularda çözüm yolu notu çıkar ve mini tekrar yap.";
        }
        return "Temel tekrar gerekli: önce konu anlatımı, sonra çözümlü örnek ve düşük seviyeden test.";
    }

    private String cleanCsv(String s) {
        if (s == null) return "";
        return s.replace('\n', ' ').replace('\r', ' ').replace(',', ' ');
    }

    public java.util.List<String> getAllPublishers() { java.util.List<String> list=new java.util.ArrayList<>(); Cursor c=getReadableDatabase().rawQuery("SELECT "+COL_BOOK_NAME+" FROM "+TABLE_BOOKS+" ORDER BY "+COL_BOOK_NAME,null); while(c.moveToNext()) list.add(c.getString(0)); c.close(); return list; }
    public int getBookIdByName(String bookName) { Cursor c=getReadableDatabase().rawQuery("SELECT "+COL_ID+" FROM "+TABLE_BOOKS+" WHERE "+COL_BOOK_NAME+"=?",new String[]{bookName}); int id=-1; if(c.moveToFirst()) id=c.getInt(0); c.close(); return id; }
}
