# Gelişmiş Özellikler Notu

Bu sürümde eklenen gelişmiş modüller:

- Konu bazlı analiz: testlerde girilen konu/ünite alanına göre doğru-yanlış-boş ve risk önceliği çıkarır.
- Haftalık çalışma hedefi: hedef test/saat bilgisi saklanır ve bu haftaki test ilerlemesi gösterilir.
- Hatırlatma sistemi: uygulama içi hatırlatma metni saklanır; Android alarmı ile bildirim tetiklenir.
- PDF/Excel dışa aktarma: PDF özet rapor ve Excel ile açılabilir CSV rapor oluşturulur.
- Grafik paneli: net trendi ve konu/yanlış yoğunluğu grafiklerle gösterilir.

Not: Sıralama/yüzdelik tahminleri resmi sonuç değildir; koçluk ve motivasyon amaçlı yaklaşık göstergedir.
