package com.beykent.akillitestanaliz;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import android.app.AlertDialog;
import android.database.Cursor;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class ExamEntryActivity extends AppCompatActivity {
    private Spinner spinnerExamType;
    private EditText etExamName;
    private LinearLayout layoutLessons;
    private TextView txtRule, txtNet, txtAnalysis;
    private LinearLayout layoutExamHistory;
    private DatabaseHelper db;
    private final List<Row> rows = new ArrayList<>();
    private int editingExamId = -1;

    static class Row {
        String name;
        String group;
        int max;
        EditText d, y, b;
        Row(String name, String group, int max, EditText d, EditText y, EditText b) {
            this.name = name;
            this.group = group;
            this.max = max;
            this.d = d;
            this.y = y;
            this.b = b;
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_exam_entry);
        if (getSupportActionBar()!=null) {
            getSupportActionBar().setTitle("Deneme Sınavı Ekle");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        db = new DatabaseHelper(this);
        spinnerExamType = findViewById(R.id.spinnerExamType);
        etExamName = findViewById(R.id.etExamName);
        layoutLessons = findViewById(R.id.layoutLessons);
        txtRule = findViewById(R.id.txtExamRule);
        txtNet = findViewById(R.id.txtCalculatedNet);
        txtAnalysis = findViewById(R.id.txtExamAnalysis);
        layoutExamHistory = findViewById(R.id.layoutExamHistory);

        spinnerExamType.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"TYT", "AYT", "LGS", "KPSS"}));
        spinnerExamType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { buildRows(spinnerExamType.getSelectedItem().toString()); }
            public void onNothingSelected(AdapterView<?> p) {}
        });
        findViewById(R.id.btnSaveExam).setOnClickListener(v -> saveExam());
        renderExamHistory();
    }

    private void buildRows(String type) {
        rows.clear();
        layoutLessons.removeAllViews();

        if (type.equals("TYT")) {
            txtRule.setText("TYT: 2 yıllık hedefler için tek başına kullanılabilir. Türkçe 40, Sosyal 20, Matematik 40, Fen 20. Fen; Fizik 7, Kimya 7, Biyoloji 6 olarak ayrı girilir.");
            addRow("Türkçe", "turkce", 40);
            addRow("Tarih", "sosyal", 5);
            addRow("Coğrafya", "sosyal", 5);
            addRow("Felsefe", "sosyal", 5);
            addRow("Din Kültürü", "sosyal", 5);
            addRow("Matematik", "mat", 40);
            addRow("Fizik", "fen", 7);
            addRow("Kimya", "fen", 7);
            addRow("Biyoloji", "fen", 6);
        } else if (type.equals("AYT")) {
            txtRule.setText("AYT: Alanlara göre dersleri gir. Girmediğin dersleri 0 bırakabilirsin. Her ders kendi soru sınırını aşamaz.");
            addRow("Edebiyat", "turkce", 24);
            addRow("Tarih-1", "sosyal", 10);
            addRow("Coğrafya-1", "sosyal", 6);
            addRow("Matematik", "mat", 40);
            addRow("Fizik", "fen", 14);
            addRow("Kimya", "fen", 13);
            addRow("Biyoloji", "fen", 13);
        } else if (type.equals("LGS")) {
            txtRule.setText("LGS: Türkçe 20, İnkılap 10, Din 10, İngilizce 10, Matematik 20, Fen 20. Toplam 90 soru.");
            addRow("Türkçe", "turkce", 20);
            addRow("İnkılap", "sosyal", 10);
            addRow("Din Kültürü", "sosyal", 10);
            addRow("İngilizce", "sosyal", 10);
            addRow("Matematik", "mat", 20);
            addRow("Fen", "fen", 20);
        } else {
            txtRule.setText("KPSS: Genel Yetenek ve Genel Kültür alanlarını ayrı gir. Soru sınırları aşılırsa kayıt yapılmaz.");
            addRow("Türkçe", "turkce", 30);
            addRow("Matematik", "mat", 30);
            addRow("Tarih", "sosyal", 27);
            addRow("Coğrafya", "sosyal", 18);
            addRow("Vatandaşlık", "sosyal", 9);
            addRow("Güncel Bilgiler", "fen", 6);
        }
        updatePreview();
    }

    private void addRow(String name, String group, int max) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(22,22,22,22);
        card.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2);
        cp.setMargins(0,0,0,12);
        card.setLayoutParams(cp);

        TextView title = new TextView(this);
        title.setText(name + " · " + max + " soru");
        title.setTextColor(0xFF0F172A);
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        card.addView(title);

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setPadding(0,12,0,0);
        EditText d = input("D");
        EditText y = input("Y");
        EditText b = input("B");
        line.addView(d); addSpace(line); line.addView(y); addSpace(line); line.addView(b);
        card.addView(line);

        TextView hint = new TextView(this);
        hint.setText("D + Y + B en fazla " + max + " olabilir.");
        hint.setTextColor(0xFF64748B);
        hint.setTextSize(12);
        hint.setPadding(0,8,0,0);
        card.addView(hint);

        layoutLessons.addView(card);
        rows.add(new Row(name, group, max, d, y, b));
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(2);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(16,0,16,0);
        e.setTextColor(0xFF111827);
        e.setHintTextColor(0xFF94A3B8);
        e.setTextSize(15);
        e.setLayoutParams(new LinearLayout.LayoutParams(0,60,1));
        e.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){ updatePreview(); } public void afterTextChanged(Editable e){} });
        return e;
    }

    private void addSpace(LinearLayout l) { Space s = new Space(this); s.setLayoutParams(new LinearLayout.LayoutParams(10,1)); l.addView(s); }
    private int val(EditText e) { String s=e.getText().toString().trim(); return s.isEmpty()?0:Integer.parseInt(s); }

    private boolean validate(boolean show) {
        for (Row r: rows) {
            try {
                int d=val(r.d), y=val(r.y), b=val(r.b);
                if (d<0 || y<0 || b<0 || d+y+b>r.max) {
                    if (show) toast(r.name + " alanında D+Y+B " + r.max + " soruyu geçemez.");
                    return false;
                }
            } catch(Exception ex) {
                if (show) toast("Sayı alanlarını kontrol et.");
                return false;
            }
        }
        return true;
    }

    private float net(Row r) { return val(r.d) - (val(r.y) / 4f); }

    private float[] aggregateNets() {
        float[] n = new float[4];
        for (Row r: rows) {
            float v = net(r);
            if (r.group.equals("turkce")) n[0] += v;
            else if (r.group.equals("sosyal")) n[1] += v;
            else if (r.group.equals("mat")) n[2] += v;
            else if (r.group.equals("fen")) n[3] += v;
        }
        return n;
    }

    private float[][] aggregateRaw() {
        float[][] a = new float[3][4];
        for (Row r: rows) {
            int idx = r.group.equals("turkce") ? 0 : r.group.equals("sosyal") ? 1 : r.group.equals("mat") ? 2 : 3;
            a[0][idx] += val(r.d);
            a[1][idx] += val(r.y);
            a[2][idx] += val(r.b);
        }
        return a;
    }

    private void updatePreview() {
        try {
            if (!validate(false)) { txtAnalysis.setText("Bir dersin toplamı soru sınırını aşıyor. Kırmızı hata almadan önce düzelt."); return; }
            float total=0; int best=0,worst=0; int filled=0,maxTotal=0;
            for(int i=0;i<rows.size();i++){
                Row r=rows.get(i);
                float n = net(r);
                total += n;
                filled += val(r.d)+val(r.y)+val(r.b);
                maxTotal += r.max;
                if(n>net(rows.get(best))) best=i;
                if(n<net(rows.get(worst))) worst=i;
            }
            txtNet.setText(String.format(Locale.US, "Toplam net: %.2f", total));
            float[] grouped = aggregateNets();
            txtAnalysis.setText("Doldurulan soru: " + filled + "/" + maxTotal +
                    "\nTürkçe: " + fmt(grouped[0]) + "  Sosyal: " + fmt(grouped[1]) +
                    "\nMatematik: " + fmt(grouped[2]) + "  Fen: " + fmt(grouped[3]) +
                    "\nEn güçlü ders: " + rows.get(best).name +
                    "\nGeliştirilecek ders: " + rows.get(worst).name +
                    "\n" + predictionText(spinnerExamType.getSelectedItem().toString(), total));
        } catch(Exception ignored) {}
    }

    private String fmt(float v) { return String.format(Locale.US, "%.2f", v); }

    private void saveExam() {
        if (etExamName.getText().toString().trim().isEmpty()) { toast("Deneme adı gir."); return; }
        if (!validate(true)) return;
        int filled = 0; for (Row r: rows) filled += val(r.d)+val(r.y)+val(r.b);
        if (filled == 0) { toast("En az bir ders için sonuç girmelisin."); return; }
        float[][] raw = aggregateRaw();
        String type = spinnerExamType.getSelectedItem().toString();
        String examName = etExamName.getText().toString().trim();
        if (editingExamId > 0) { db.deleteExamById(editingExamId); editingExamId = -1; }
        db.setActiveExamType(type);
        saveDetailedLessonRows(type, examName);
        updatePreview();
        clearExamForm();
        renderExamHistory();
        toast("Deneme kaydedildi. " + predictionText(type, sum(aggregateNets())));
        findViewById(R.id.btnSaveExam).setOnClickListener(v -> saveExam());
    }


    private void saveDetailedLessonRows(String type, String examName) {
        String[] names = new String[rows.size()];
        String[] groups = new String[rows.size()];
        int[] maxes = new int[rows.size()];
        float[] d = new float[rows.size()];
        float[] y = new float[rows.size()];
        float[] b = new float[rows.size()];
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            names[i] = r.name;
            groups[i] = r.group;
            maxes[i] = r.max;
            d[i] = val(r.d);
            y[i] = val(r.y);
            b[i] = val(r.b);
        }
        db.saveCompleteExamResult(type, examName, names, groups, maxes, d, y, b);
    }

    private float sum(float[] values) { float t = 0; for (float v: values) t += v; return t; }


    private void clearExamForm() {
        etExamName.setText("");
        for (Row r : rows) { r.d.setText(""); r.y.setText(""); r.b.setText(""); }
        updatePreview();
        etExamName.requestFocus();
    }

    private void renderExamHistory() {
        if (layoutExamHistory == null) return;
        layoutExamHistory.removeAllViews();
        Cursor c = db.getExamHistoryManage(5);
        if (!c.moveToFirst()) {
            addExamHistoryCard(-1, "Henüz deneme yok", "Kaydettiğin son 5 deneme burada görünecek. Eski kayıtlar analizde hesaplanır.", false);
            c.close(); return;
        }
        do {
            int id = c.getInt(0); String type = c.getString(1); String name = c.getString(2); float total = c.getFloat(3);
            String body = type + " · Toplam net: " + fmt(total) + "\nTürkçe: " + fmt(c.getFloat(4)) + " | Sosyal: " + fmt(c.getFloat(5)) + "\nMatematik: " + fmt(c.getFloat(6)) + " | Fen: " + fmt(c.getFloat(7)) + "\nDokun: Güncelle / Sil";
            addExamHistoryCard(id, name, body, total >= 70);
        } while (c.moveToNext());
        c.close();
    }

    private void addExamHistoryCard(int id, String titleText, String bodyText, boolean good) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 18, 18, 18);
        card.setBackgroundResource(good ? R.drawable.bg_test_solved : R.drawable.bg_card);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, 12); card.setLayoutParams(lp);
        TextView title = new TextView(this); title.setText(titleText); title.setTextSize(15); title.setTextColor(0xFF0F172A); title.setTypeface(null, Typeface.BOLD);
        TextView body = new TextView(this); body.setText(bodyText); body.setTextSize(13); body.setTextColor(0xFF475569); body.setPadding(0, 6, 0, 0); body.setLineSpacing(3, 1);
        card.addView(title); card.addView(body);
        if (id > 0) {
            card.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Deneme kaydı")
                    .setMessage("Bu deneme için işlem seç.")
                    .setPositiveButton("Güncelle", (d, w) -> loadExamForUpdate(id, titleText))
                    .setNegativeButton("Sil", (d, w) -> { db.deleteExamById(id); renderExamHistory(); toast("Deneme silindi."); })
                    .setNeutralButton("Vazgeç", null)
                    .show());
        }
        layoutExamHistory.addView(card);
    }

    private void loadExamForUpdate(int id, String name) {
        Cursor c = db.getExamLessonsByExamId(id);
        if (!c.moveToFirst()) { c.close(); toast("Bu denemenin ders kayıtları bulunamadı."); return; }
        editingExamId = id;
        etExamName.setText(name);
        do {
            String lesson = c.getString(0);
            for (Row r : rows) {
                if (r.name.equals(lesson)) {
                    r.d.setText(String.valueOf((int)c.getFloat(3)));
                    r.y.setText(String.valueOf((int)c.getFloat(4)));
                    r.b.setText(String.valueOf((int)c.getFloat(5)));
                    break;
                }
            }
        } while(c.moveToNext());
        c.close();
        txtAnalysis.setText("Güncelleme modu açık. Kaydet dediğinde eski deneme silinip yeni değerlerle kaydedilir. Sınav türü farklıysa önce türü seçip değerleri tekrar gir.");
        toast("Deneme güncelleme moduna alındı.");
    }

    private String predictionText(String type, float net) {
        if (type.equals("LGS")) {
            String pct;
            if (net >= 82) pct = "%0.1 - %1.0";
            else if (net >= 75) pct = "%1 - %3";
            else if (net >= 65) pct = "%3 - %8";
            else if (net >= 50) pct = "%8 - %20";
            else pct = "%20+";
            return "Yaklaşık LGS yüzdelik aralığı: " + pct + " (resmi değil, koçluk tahmini)";
        }
        if (type.equals("TYT")) {
            return "TYT başarı yorumu: " + tytBand(net) + " (2 yıllık programlar için TYT ağırlıklıdır; 4 yıllık hedeflerde AYT de gerekir)";
        }
        if (type.equals("AYT")) {
            return "Yaklaşık YKS başarı aralığı: " + aytBand(net) + " (resmi değil, TYT+AYT birlikte değerlendirilir)";
        }
        if (type.equals("KPSS")) {
            return "Yaklaşık KPSS başarı aralığı: " + kpssBand(net) + " (resmi değil, koçluk tahmini)";
        }
        return "Tahmini sonuç için daha fazla deneme verisi gerekli.";
    }

    private String tytBand(float net) {
        if (net >= 105) return "çok güçlü tempo / ilk 100 bin potansiyeli";
        if (net >= 90) return "güçlü tempo / ilk 100-250 bin bandı";
        if (net >= 75) return "orta-iyi tempo / ilk 250-500 bin bandı";
        if (net >= 55) return "gelişen tempo / 500 bin-1 milyon bandı";
        return "temel tekrar gerekli / 1 milyon+ risk bandı";
    }

    private String aytBand(float net) {
        if (net >= 65) return "çok güçlü";
        if (net >= 50) return "güçlü";
        if (net >= 35) return "orta";
        if (net >= 20) return "gelişiyor";
        return "riskli";
    }

    private String kpssBand(float net) {
        if (net >= 95) return "çok güçlü / üst sıralar";
        if (net >= 80) return "güçlü / rekabetçi";
        if (net >= 65) return "orta / yükseltilebilir";
        if (net >= 45) return "riskli / konu eksiği var";
        return "acil temel tekrar";
    }

    private void toast(String m){ Toast.makeText(this,m,Toast.LENGTH_LONG).show(); }
    @Override public boolean onSupportNavigateUp(){ finish(); return true; }
}
