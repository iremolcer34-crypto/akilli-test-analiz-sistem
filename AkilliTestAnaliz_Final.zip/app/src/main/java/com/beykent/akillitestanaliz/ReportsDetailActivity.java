package com.beykent.akillitestanaliz;

import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ReportsDetailActivity extends AppCompatActivity {

    private TextView txtTavsiye;
    private LinearLayout layoutUniteDetay;
    private DatabaseHelper dbHelper;
    private String dersAdi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_detail);

        dersAdi = getIntent().getStringExtra("ders_adi");
        if (dersAdi == null) dersAdi = "Ders";

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(dersAdi + " Analizi");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        txtTavsiye       = findViewById(R.id.txtTavsiye);
        layoutUniteDetay = findViewById(R.id.layoutUniteDetay);
        dbHelper         = new DatabaseHelper(this);

        buildUI();
    }

    private void buildUI() {
        layoutUniteDetay.removeAllViews();

        int[] o = dbHelper.getDersGenelOzet(dersAdi);
        int toplamD = o[0], toplamY = o[1], toplamB = o[2];
        int toplam = toplamD + toplamY + toplamB;
        float net = toplamD - (toplamY / 4.0f);
        int basari = toplam > 0 ? Math.round((toplamD * 100f) / toplam) : 0;
        String seviye = levelText(basari);
        String risk = riskText(basari, toplamY, toplamB);

        // Üst koç kartı: ekrandaki boş ve sade görünümü kırar.
        txtTavsiye.setText(
                "🧠 " + dersAdi + " Koç Yorumu\n\n" +
                buildCoachComment(basari, toplamY, toplamB, net, seviye)
        );
        txtTavsiye.setTextSize(15);
        txtTavsiye.setTypeface(null, Typeface.BOLD);
        txtTavsiye.setLineSpacing(7, 1);

        // Başarı skoru kartı
        LinearLayout scoreCard = createCard();
        addLabel(scoreCard, "🏆 Başarı Skoru", 16, "#0F172A", true);
        addLabel(scoreCard, "%" + basari, 34, scoreColor(basari), true);
        addLabel(scoreCard, "Net: " + String.format("%.2f", net) + "  •  Seviye: " + seviye + "  •  Risk: " + risk, 13, "#475569", false);
        addProgressBar(scoreCard, basari, 22);
        layoutUniteDetay.addView(scoreCard);

        // Mini istatistik kartları
        LinearLayout statGrid1 = horizontalRow();
        statGrid1.addView(statBox("✅ Doğru", String.valueOf(toplamD), "#16A34A"));
        statGrid1.addView(statBox("❌ Yanlış", String.valueOf(toplamY), "#DC2626"));
        layoutUniteDetay.addView(statGrid1);

        LinearLayout statGrid2 = horizontalRow();
        statGrid2.addView(statBox("⬜ Boş", String.valueOf(toplamB), "#64748B"));
        statGrid2.addView(statBox("🎯 Net", String.format("%.2f", net), "#2563EB"));
        layoutUniteDetay.addView(statGrid2);

        // Strateji kartı
        LinearLayout strategyCard = createCard();
        addLabel(strategyCard, "🎯 Bu Derse Nasıl Çalışmalısın?", 16, "#0F172A", true);
        addLabel(strategyCard, buildStrategy(basari, toplamY, toplamB), 14, "#334155", false);
        layoutUniteDetay.addView(strategyCard);

        // Risk ve hedef kartı
        LinearLayout goalCard = createCard();
        addLabel(goalCard, "⚠️ Risk Analizi ve Sonraki Hedef", 16, "#0F172A", true);
        addLabel(goalCard, buildRiskGoal(basari, toplamD, toplamY, toplamB, net), 14, "#334155", false);
        layoutUniteDetay.addView(goalCard);

        // Ünite analizleri
        addSectionTitle("📊 Ünite Bazlı Performans");
        Cursor cursor = dbHelper.getUniteOzetiByDers(dersAdi);
        if (cursor == null || cursor.getCount() == 0) {
            LinearLayout empty = createCard();
            addLabel(empty, "Henüz ünite verisi yok", 16, "#0F172A", true);
            addLabel(empty, "Bu derse ait test sonucu ekleyince ünite başarısı, riskli konu ve hedef önerisi burada görünecek.", 14, "#64748B", false);
            layoutUniteDetay.addView(empty);
            if (cursor != null) cursor.close();
            return;
        }

        String weakestUnit = "";
        int weakestScore = 101;
        if (cursor.moveToFirst()) {
            do {
                String uniteAdi = safe(cursor.getString(0), "Genel");
                int uD = cursor.getInt(1);
                int uY = cursor.getInt(2);
                int uB = cursor.getInt(3);
                int testSayisi = cursor.getInt(4);
                int uToplam = uD + uY + uB;
                float uNet = uD - (uY / 4.0f);
                int uBasari = uToplam > 0 ? Math.round((uD * 100f) / uToplam) : 0;
                if (uToplam > 0 && uBasari < weakestScore) {
                    weakestScore = uBasari;
                    weakestUnit = uniteAdi;
                }

                LinearLayout kart = createCard();
                addLabel(kart, uniteAdi, 17, "#0F172A", true);
                addLabel(kart, testSayisi + " test çözüldü  •  Başarı: %" + uBasari, 13, "#64748B", false);

                LinearLayout chips = horizontalRow();
                chips.addView(smallChip("D " + uD, "#DCFCE7", "#166534"));
                chips.addView(smallChip("Y " + uY, "#FEE2E2", "#991B1B"));
                chips.addView(smallChip("B " + uB, "#F1F5F9", "#475569"));
                layoutSpacing(chips, 0, 10, 0, 8);
                kart.addView(chips);

                addLabel(kart, "Net: " + String.format("%.1f", uNet) + "  •  " + unitAdvice(uBasari, uY, uB), 13, "#334155", false);
                addProgressBar(kart, uBasari, 18);
                layoutUniteDetay.addView(kart);
            } while (cursor.moveToNext());
        }
        cursor.close();

        // Son hedef kartı
        LinearLayout nextCard = createCard();
        addLabel(nextCard, "🚀 Sonraki Mini Hedef", 16, "#0F172A", true);
        if (weakestUnit.length() > 0) {
            addLabel(nextCard, weakestUnit + " için 1 konu tekrarı + 1 mini test çöz. Hedef: bu derste başarıyı %" + Math.min(100, weakestScore + 5) + " seviyesine taşımak.", 14, "#334155", false);
        } else {
            addLabel(nextCard, "Bu derste veri az. Önce 1 test sonucu ekle, sonra hedef otomatik oluşacak.", 14, "#334155", false);
        }
        layoutUniteDetay.addView(nextCard);
    }

    private String buildCoachComment(int basari, int y, int b, float net, String seviye) {
        if (basari >= 90) {
            return "Bu ders güçlü görünüyor. Yeni konu yüklemek yerine hız, dikkat ve süre kontrolü çalış. Neti korumak için haftada 2 mini tekrar testi yeterli.";
        }
        if (basari >= 70) {
            return "Temel iyi ama hâlâ net artışı var. Yanlış çıkan konuları video + kısa tekrar + mini test döngüsüyle kapat.";
        }
        if (basari > 0) {
            return "Bu ders riskli. Önce konu eksiği kapatılmalı. Her çalışmada 20 dakika konu tekrarı, ardından 1 mini test yap.";
        }
        return "Henüz veri yok. Bu dersten ilk test sonucunu ekleyince koç yorumu otomatik oluşacak.";
    }

    private String buildStrategy(int basari, int y, int b) {
        if (basari >= 90) {
            return "• Süre tutarak çöz.\n• Zor sorulara takılıp süre kaybetme.\n• Yanlış çıkan soruları aynı gün yanlış kutusuna al.\n• Haftada 2 kısa tekrar testi yeterli.";
        }
        if (basari >= 70) {
            return "• En çok yanlış gelen konuyu seç.\n• 20 dk konu tekrarı yap.\n• 1 öğretici video izle.\n• Hemen ardından 1 mini test çöz.\n• Yanlışları tekrar listesine taşı.";
        }
        return "• Konu anlatımıyla başla.\n• Not çıkar, sonra kolay test çöz.\n• Yanlışları video/hoca aşamasına taşı.\n• 3 gün üst üste kısa tekrar yapmadan deneme çözme.";
    }

    private String buildRiskGoal(int basari, int d, int y, int b, float net) {
        String focus = y >= b ? "yanlış sayısını azaltmak" : "boş bırakılan soruları azaltmak";
        int nextSuccess = Math.min(100, basari + 5);
        float nextNet = net + 1.0f;
        return "Risk odağı: " + focus + ".\n" +
               "Bir sonraki hedef: başarıyı %" + basari + " → %" + nextSuccess + " yapmak.\n" +
               "Net hedefi: " + String.format("%.2f", net) + " → " + String.format("%.2f", nextNet) + ".\n" +
               "Bugünkü görev: en zayıf üniteden 1 mini test + yanlış kutusu kontrolü.";
    }

    private String unitAdvice(int basari, int y, int b) {
        if (basari >= 90) return "Güçlü. Hız ve dikkat çalış.";
        if (y > b) return "Yanlış ağırlıklı. Konu tekrar + video önerilir.";
        if (b > y) return "Boş ağırlıklı. Süre yönetimi çalış.";
        return "Orta seviye. Mini test ile pekiştir.";
    }

    private String levelText(int basari) {
        if (basari >= 90) return "Güçlü";
        if (basari >= 70) return "Orta-İyi";
        if (basari > 0) return "Riskli";
        return "Veri Yok";
    }

    private String riskText(int basari, int y, int b) {
        if (basari >= 90 && y <= 2) return "Düşük";
        if (basari >= 70) return y > b ? "Yanlış ağırlıklı" : "Boş/süre ağırlıklı";
        if (basari > 0) return "Yüksek";
        return "Belirsiz";
    }

    private String scoreColor(int basari) {
        if (basari >= 90) return "#16A34A";
        if (basari >= 70) return "#2563EB";
        if (basari > 0) return "#DC2626";
        return "#64748B";
    }

    private String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(36, 32, 36, 32);
        card.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, 18);
        card.setLayoutParams(p);
        return card;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, 14);
        row.setLayoutParams(p);
        return row;
    }

    private void addSectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(18);
        tv.setTextColor(Color.parseColor("#0F172A"));
        tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 12);
        tv.setLayoutParams(p);
        layoutUniteDetay.addView(tv);
    }

    private void addLabel(LinearLayout parent, String text, int sizeSp, String colorHex, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setLineSpacing(5, 1);
        if (bold) tv.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 4, 0, 4);
        tv.setLayoutParams(p);
        parent.addView(tv);
    }

    private TextView statBox(String label, String value, String colorHex) {
        TextView tv = new TextView(this);
        tv.setText(label + "\n" + value);
        tv.setTextSize(15);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(Color.parseColor(colorHex));
        tv.setBackgroundResource(R.drawable.bg_card);
        tv.setPadding(20, 24, 20, 24);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        p.setMargins(0, 0, 10, 12);
        tv.setLayoutParams(p);
        return tv;
    }

    private TextView smallChip(String text, String bg, String fg) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(Color.parseColor(fg));
        tv.setBackgroundColor(Color.parseColor(bg));
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(12, 8, 12, 8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        p.setMargins(0, 0, 8, 0);
        tv.setLayoutParams(p);
        return tv;
    }

    private void layoutSpacing(LinearLayout view, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(l, t, r, b);
        view.setLayoutParams(p);
    }

    private void addProgressBar(LinearLayout parent, int progress, int height) {
        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setProgress(Math.max(0, Math.min(100, progress)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height);
        p.setMargins(0, 10, 0, 0);
        pb.setLayoutParams(p);
        parent.addView(pb);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
