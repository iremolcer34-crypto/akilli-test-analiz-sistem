package com.beykent.akillitestanaliz;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ExamTimeSettingActivity extends AppCompatActivity {

    private TextView txtTitle, lbl1, lbl2, lbl3, lbl4;
    private EditText edt1, edt2, edt3, edt4;
    private Spinner spinnerExam;
    private String exam, k1, k2, k3, k4;
    private final String[] exams = new String[]{TimePrefs.EXAM_TYT, TimePrefs.EXAM_AYT, TimePrefs.EXAM_LGS, TimePrefs.EXAM_KPSS};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam_time_settings);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Sınav Süreleri");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        exam = getIntent().getStringExtra("exam");
        if (TextUtils.isEmpty(exam)) exam = TimePrefs.EXAM_TYT;

        initViews();
        setupSpinner();
        setupForExam(exam);
        loadValues();

        findViewById(R.id.btnSaveTimes).setOnClickListener(v -> {
            saveValues();
            Toast.makeText(this, exam + " süreleri güncellendi", Toast.LENGTH_SHORT).show();
        });
    }

    private void initViews() {
        txtTitle = findViewById(R.id.txtExamTitle);
        spinnerExam = findViewById(R.id.spinnerExamType);
        lbl1 = findViewById(R.id.lbl1); lbl2 = findViewById(R.id.lbl2);
        lbl3 = findViewById(R.id.lbl3); lbl4 = findViewById(R.id.lbl4);
        edt1 = findViewById(R.id.edt1); edt2 = findViewById(R.id.edt2);
        edt3 = findViewById(R.id.edt3); edt4 = findViewById(R.id.edt4);
    }

    private void setupSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, exams);
        spinnerExam.setAdapter(adapter);
        for (int i = 0; i < exams.length; i++) if (exams[i].equals(exam)) spinnerExam.setSelection(i);
        spinnerExam.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int pos, long id) {
                String selected = exams[pos];
                if (!selected.equals(exam)) {
                    exam = selected;
                    setupForExam(exam);
                    loadValues();
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private void setupForExam(String exam) {
        txtTitle.setText("Ders Süreleri (" + exam + ")");
        if (TimePrefs.EXAM_AYT.equals(exam)) {
            k1 = TimePrefs.L_EDEB; k2 = TimePrefs.L_MAT2; k3 = TimePrefs.L_AYT_SOS; k4 = TimePrefs.L_AYT_FEN;
            lbl1.setText("Edebiyat / Türk Dili (dk)"); lbl2.setText("Matematik-2 (dk)"); lbl3.setText("AYT Sosyal (dk)"); lbl4.setText("AYT Fen (dk)");
        } else if (TimePrefs.EXAM_LGS.equals(exam)) {
            k1 = TimePrefs.L_TURKCE; k2 = TimePrefs.L_MAT; k3 = TimePrefs.L_SOS; k4 = TimePrefs.L_FEN;
            lbl1.setText("Türkçe (dk)"); lbl2.setText("Matematik (dk)"); lbl3.setText("Sosyal / Din / İngilizce (dk)"); lbl4.setText("Fen (dk)");
        } else if (TimePrefs.EXAM_KPSS.equals(exam)) {
            k1 = TimePrefs.L_GY; k2 = TimePrefs.L_GK; k3 = TimePrefs.L_EGITIM; k4 = TimePrefs.L_ALAN;
            lbl1.setText("Genel Yetenek (dk)"); lbl2.setText("Genel Kültür (dk)"); lbl3.setText("Eğitim Bilimleri (dk)"); lbl4.setText("Alan Bilgisi (dk)");
        } else {
            k1 = TimePrefs.L_TURKCE; k2 = TimePrefs.L_MAT; k3 = TimePrefs.L_SOS; k4 = TimePrefs.L_FEN;
            lbl1.setText("Türkçe (dk)"); lbl2.setText("Matematik (dk)"); lbl3.setText("Sosyal (dk)"); lbl4.setText("Fen (dk)");
        }
    }

    private void loadValues() {
        int[] defaults = getDefaultsForExam(exam);
        edt1.setText(String.valueOf(TimePrefs.getMinutes(this, exam, k1, defaults[0])));
        edt2.setText(String.valueOf(TimePrefs.getMinutes(this, exam, k2, defaults[1])));
        edt3.setText(String.valueOf(TimePrefs.getMinutes(this, exam, k3, defaults[2])));
        edt4.setText(String.valueOf(TimePrefs.getMinutes(this, exam, k4, defaults[3])));
    }

    private int[] getDefaultsForExam(String exam) {
        if (TimePrefs.EXAM_AYT.equals(exam)) return new int[]{60, 80, 40, 40};
        if (TimePrefs.EXAM_LGS.equals(exam)) return new int[]{50, 60, 30, 40};
        if (TimePrefs.EXAM_KPSS.equals(exam)) return new int[]{60, 60, 75, 90};
        return new int[]{55, 75, 25, 35};
    }

    private void saveValues() {
        TimePrefs.putMinutes(this, exam, k1, parseIntSafe(edt1.getText().toString()));
        TimePrefs.putMinutes(this, exam, k2, parseIntSafe(edt2.getText().toString()));
        TimePrefs.putMinutes(this, exam, k3, parseIntSafe(edt3.getText().toString()));
        TimePrefs.putMinutes(this, exam, k4, parseIntSafe(edt4.getText().toString()));
    }

    private int parseIntSafe(String s) {
        try { return Math.max(0, Math.min(300, Integer.parseInt(s.trim()))); }
        catch (Exception e) { return 0; }
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
