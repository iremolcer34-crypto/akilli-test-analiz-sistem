package com.beykent.akillitestanaliz;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class TestAdapter extends RecyclerView.Adapter<TestAdapter.TestViewHolder> {
    private final List<String> testList;
    private final int bookId;
    private final DatabaseHelper dbHelper;

    public TestAdapter(List<String> testList, int bookId, DatabaseHelper dbHelper) {
        this.testList = testList;
        this.bookId = bookId;
        this.dbHelper = dbHelper;
    }

    @NonNull @Override public TestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_test_row, parent, false);
        return new TestViewHolder(view);
    }

    @Override public void onBindViewHolder(@NonNull TestViewHolder holder, int position) {
        String testName = testList.get(position);
        int testNumber = position + 1;
        boolean solved = dbHelper.isTestSolved(bookId, testNumber);
        holder.txtTestNo.setText(testName);
        holder.txtTestHint.setText(solved ? "Kayıtlı sonucu güncellemek veya silmek için dokun" : "Doğru / yanlış / boş sonucu eklemek için dokun");
        holder.txtStatusBadge.setText(solved ? "Kaydedildi" : "Boş");
        holder.itemView.setBackgroundResource(solved ? R.drawable.bg_test_solved : R.drawable.bg_card);
        holder.txtTestNo.setTextColor(solved ? Color.parseColor("#166534") : Color.parseColor("#111827"));
        holder.txtStatusBadge.setTextColor(solved ? Color.parseColor("#166534") : Color.parseColor("#2563EB"));
        holder.itemView.setOnClickListener(v -> {
            if (dbHelper.isTestSolved(bookId, testNumber)) showSolvedOptions(v, testName, testNumber, position);
            else showResultDialog(v, testName, testNumber, position);
        });
    }

    private void showSolvedOptions(View v, String testName, int testNumber, int position) {
        new AlertDialog.Builder(v.getContext())
                .setTitle(testName)
                .setMessage("Bu test daha önce kaydedilmiş. Ne yapmak istiyorsun?")
                .setPositiveButton("Güncelle", (d, w) -> showResultDialog(v, testName, testNumber, position))
                .setNegativeButton("Sil", (d, w) -> confirmDelete(v, testName, testNumber, position))
                .setNeutralButton("Vazgeç", null)
                .show();
    }

    private void confirmDelete(View v, String testName, int testNumber, int position) {
        new AlertDialog.Builder(v.getContext())
                .setTitle(testName + " silinsin mi?")
                .setMessage("Bu test sonucu silinirse kitap ilerleme yüzdesi de geri düşer.")
                .setPositiveButton("Sil", (dialog, which) -> {
                    dbHelper.deleteTestResult(bookId, testNumber);
                    notifyItemChanged(position);
                    refreshParent(v);
                    Toast.makeText(v.getContext(), "Test sonucu silindi.", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("İptal", null)
                .show();
    }

    private void showResultDialog(View v, String testName, int testNumber, int position) {
        LinearLayout layout = new LinearLayout(v.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(42, 24, 42, 8);
        layout.addView(text(v, "Sonucu mantıklı gir: Doğru + Yanlış + Boş, toplam soruya eşit olmalı.", 13, "#64748B", false));

        EditText etTotal = input(v, "Toplam soru sayısı");
        EditText etCorrect = input(v, "Doğru sayısı");
        EditText etWrong = input(v, "Yanlış sayısı");
        EditText etEmpty = input(v, "Boş sayısı");
        layout.addView(label(v, "Toplam soru")); layout.addView(etTotal);
        layout.addView(label(v, "Doğru")); layout.addView(etCorrect);
        layout.addView(label(v, "Yanlış")); layout.addView(etWrong);
        layout.addView(label(v, "Boş")); layout.addView(etEmpty);

        int[] old = dbHelper.getTestResult(bookId, testNumber);
        if (old != null) {
            int total = old[0] + old[1] + old[2];
            etTotal.setText(String.valueOf(total));
            etCorrect.setText(String.valueOf(old[0]));
            etWrong.setText(String.valueOf(old[1]));
            etEmpty.setText(String.valueOf(old[2]));
        }

        AlertDialog dialog = new AlertDialog.Builder(v.getContext())
                .setTitle(testName + (old == null ? " — Sonuç Ekle" : " — Sonuç Güncelle"))
                .setView(layout)
                .setPositiveButton(old == null ? "Kaydet" : "Güncelle", null)
                .setNegativeButton("İptal", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            try {
                int total = parse(etTotal), correct = parse(etCorrect), wrong = parse(etWrong), empty = parse(etEmpty);
                if (total <= 0 || total > 300) { toast(v, "Toplam soru 1-300 arasında olmalı."); return; }
                if (correct < 0 || wrong < 0 || empty < 0) { toast(v, "Negatif değer girilemez."); return; }
                if (correct + wrong + empty != total) { toast(v, "Doğru + yanlış + boş, toplam soru sayısına eşit olmalı."); return; }
                String uniteName = getUniteName(testNumber);
                dbHelper.saveTestResult(bookId, testNumber, uniteName, correct, wrong, empty);
                notifyItemChanged(position);
                refreshParent(v);
                dialog.dismiss();
                showAnalizDialog(v, testName, uniteName, correct, wrong, empty);
            } catch (Exception ex) { toast(v, "Sayı alanlarını kontrol et."); }
        }));
        dialog.show();
    }

    private EditText input(View v, String hint) {
        EditText e = new EditText(v.getContext());
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setBackgroundResource(R.drawable.bg_input);
        e.setTextColor(Color.parseColor("#111827"));
        e.setHintTextColor(Color.parseColor("#94A3B8"));
        e.setPadding(18, 0, 18, 0);
        e.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 54);
        lp.setMargins(0, 0, 0, 12);
        e.setLayoutParams(lp);
        return e;
    }

    private TextView label(View v, String s) {
        TextView t = new TextView(v.getContext());
        t.setText(s); t.setTextSize(13); t.setTextColor(Color.parseColor("#334155")); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 8, 0, 6);
        return t;
    }

    private void refreshParent(View v) {
        if (v.getContext() instanceof BookDetailActivity) ((BookDetailActivity) v.getContext()).refreshProgress();
    }

    private int parse(EditText e) { return Integer.parseInt(e.getText().toString().trim()); }
    private void toast(View v, String msg) { Toast.makeText(v.getContext(), msg, Toast.LENGTH_LONG).show(); }

    private String getUniteName(int testNumber) {
        if (testNumber <= 4) return "1. Ünite";
        if (testNumber <= 8) return "2. Ünite";
        if (testNumber <= 12) return "3. Ünite";
        if (testNumber <= 16) return "4. Ünite";
        return "5. Ünite";
    }

    private void showAnalizDialog(View v, String testName, String uniteName, int correct, int wrong, int empty) {
        int total = correct + wrong + empty;
        float net = correct - (wrong / 4.0f);
        int success = total > 0 ? Math.round((correct * 100f) / total) : 0;
        LinearLayout layout = new LinearLayout(v.getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(46, 36, 46, 20);
        layout.addView(text(v, "📊 " + testName + " Analizi", 19, "#0F172A", true));
        layout.addView(text(v, "Net: " + String.format(Locale.US, "%.2f", net) + "   Başarı: %" + success, 24, "#2563EB", true));
        layout.addView(text(v, "Doğru: " + correct + "  |  Yanlış: " + wrong + "  |  Boş: " + empty + "\n" + generateKocMesaji(wrong, empty, success, uniteName), 14, "#475569", false));
        new AlertDialog.Builder(v.getContext()).setView(layout).setPositiveButton("Tamam", null).show();
    }

    private TextView text(View v, String s, int sp, String color, boolean bold) {
        TextView t = new TextView(v.getContext());
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.parseColor(color));
        t.setPadding(0, 0, 0, 12); t.setLineSpacing(4, 1);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private String generateKocMesaji(int wrong, int empty, int success, String uniteName) {
        if (success >= 85) return "Harika. " + uniteName + " güçlü görünüyor. Yanlışları kapatıp bir sonraki teste geç.";
        if (success >= 65) return uniteName + " fena değil ama " + wrong + " yanlış var. Yanlış Kutusu'nda video/hoca takibi yap.";
        return uniteName + " zayıf. Önce konu tekrarı, sonra çözümlü örnek, sonra aynı test tipiyle tekrar çözüm yap.";
    }

    @Override public int getItemCount() { return testList != null ? testList.size() : 0; }

    public static class TestViewHolder extends RecyclerView.ViewHolder {
        TextView txtTestNo, txtTestHint, txtStatusBadge;
        public TestViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTestNo = itemView.findViewById(R.id.txtTestNo);
            txtTestHint = itemView.findViewById(R.id.txtTestHint);
            txtStatusBadge = itemView.findViewById(R.id.txtStatusBadge);
        }
    }
}
