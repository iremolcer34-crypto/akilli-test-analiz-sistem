package com.beykent.akillitestanaliz;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class BookDetailActivity extends AppCompatActivity {

    private RecyclerView rvTests;
    private TextView txtBookDetailTitle, txtBookProgressSummary;
    private ProgressBar progressBookDetail;

    private DatabaseHelper dbHelper;
    private TestAdapter testAdapter;

    private int bookId;
    private String bookName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        bookId = getIntent().getIntExtra("BOOK_ID", -1);
        bookName = getIntent().getStringExtra("BOOK_NAME");

        rvTests = findViewById(R.id.rvTests);
        txtBookDetailTitle = findViewById(R.id.txtBookDetailTitle);
        txtBookProgressSummary = findViewById(R.id.txtBookProgressSummary);
        progressBookDetail = findViewById(R.id.progressBookDetail);

        dbHelper = new DatabaseHelper(this);

        if (bookName != null) {
            txtBookDetailTitle.setText(bookName);
        }

        rvTests.setLayoutManager(new LinearLayoutManager(this));

        loadTestsFromDatabase();
    }

    private void loadTestsFromDatabase() {
        List<String> testList = new ArrayList<>();

        int totalTests = dbHelper.getBookTotalTests(bookId);
        for (int i = 1; i <= totalTests; i++) {
            testList.add("Test " + i);
        }

        refreshProgress();
        testAdapter = new TestAdapter(testList, bookId, dbHelper);
        rvTests.setAdapter(testAdapter);
    }

    public void refreshProgress() {
        int total = dbHelper.getBookTotalTests(bookId);
        int percent = dbHelper.getBookProgress(bookId);
        int solved = dbHelper.getBookSolvedTestCount(bookId);
        float percentExact = total <= 0 ? 0f : (solved * 100f / total);
        String percentText = percentExact == Math.round(percentExact)
                ? String.valueOf(Math.round(percentExact))
                : String.format(java.util.Locale.US, "%.1f", percentExact);
        if (progressBookDetail != null) progressBookDetail.setProgress(Math.min(100, Math.max(0, Math.round(percentExact))));
        if (txtBookProgressSummary != null) txtBookProgressSummary.setText(solved + "/" + total + " test tamamlandı · %" + percentText);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTestsFromDatabase();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}