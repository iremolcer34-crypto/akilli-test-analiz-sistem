# Analiz ve Tahmini Sonuç Notu

Bu uygulamada analizler; kullanıcının girdiği test, deneme ve yanlış kutusu verileri üzerinden hesaplanır.

## Eklenen analiz özellikleri
- Son denemelere göre görsel net trendi
- Ders bazlı deneme karnesi
- Yanlış yoğunluğu grafiği
- Riskli ders öncelik listesi
- Koç aksiyon planı
- Son test geçmişi özeti
- Güçlü / zayıf ders tespiti

## Tahmini sıralama ve yüzdelik
LGS yüzdelik, YKS/KPSS sıralama çıktıları resmi MEB/ÖSYM sonucu değildir. Kullanıcıya hedef takibi ve motivasyon sağlamak için yaklaşık bir koçluk göstergesi olarak verilmiştir.

Sunumda doğru anlatım:
> Uygulama resmi sıralama hesaplamaz; girilen netlere göre yaklaşık bir performans tahmini ve çalışma önerisi üretir.
