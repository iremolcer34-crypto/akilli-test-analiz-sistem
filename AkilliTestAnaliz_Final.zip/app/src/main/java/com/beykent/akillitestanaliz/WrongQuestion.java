package com.beykent.akillitestanaliz;

public class WrongQuestion {
    public int id;
    public String bookName;
    public String unite;
    public int soruNo;
    public String teacherName;
    public String videoUrl;
    public int isResolved;

    public WrongQuestion(int id, String bookName, String unite, int soruNo, String teacherName, String videoUrl, int isResolved) {
        this.id = id;
        this.bookName = bookName;
        this.unite = unite;
        this.soruNo = soruNo;
        this.teacherName = teacherName;
        this.videoUrl = videoUrl;
        this.isResolved = isResolved;
    }
}