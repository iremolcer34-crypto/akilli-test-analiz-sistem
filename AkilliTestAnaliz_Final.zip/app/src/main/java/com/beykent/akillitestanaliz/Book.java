package com.beykent.akillitestanaliz;

public class Book {
    private int id, totalTests, progress;
    private String name, subject;

    public Book(int id, String name, String subject, int totalTests, int progress) {
        this.id = id;
        this.name = name;
        this.subject = subject;
        this.totalTests = totalTests;
        this.progress = progress;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getSubject() { return subject; }
    public int getProgressPercentage() {
        return Math.max(0, Math.min(100, progress));
    }
}