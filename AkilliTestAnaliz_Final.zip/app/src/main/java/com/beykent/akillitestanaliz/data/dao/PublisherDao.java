package com.beykent.akillitestanaliz.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.beykent.akillitestanaliz.data.entity.Publisher;

import java.util.List;

@Dao
public interface PublisherDao {

    @Insert
    long insert(Publisher p);

    @Query("SELECT * FROM publishers ORDER BY id DESC")
    List<Publisher> getAll();
}
